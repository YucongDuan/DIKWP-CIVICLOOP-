import tempfile
import unittest
from pathlib import Path

from common import make_event, make_runtime


class DecisionRightsTests(unittest.TestCase):
    def test_public_service_denial_requires_human_or_block(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            event = make_event(domain="social_security", action_type="deny", impact_level="HIGH", final_adverse_decision=True, critical_service=True)
            proof = rt.control.evaluate(event)
            result = rt.rights.compile(event, proof.state)
            self.assertIn(result.mode, {"REQUIRE_HUMAN", "BLOCK", "FREEZE_RECOVER"})
            self.assertNotEqual(result.mode, "EXECUTE_REVERSIBLE")

    def test_no_appeal_blocks_adverse_decision(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            event = make_event(domain="finance", action_type="deny", final_adverse_decision=True, appeal_available=False, impact_level="HIGH")
            proof = rt.control.evaluate(event)
            result = rt.rights.compile(event, proof.state)
            self.assertEqual(result.mode, "BLOCK")

    def test_reversible_low_impact_can_execute(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            event = make_event(domain="consumer", action_type="recommend", requested_mode="EXECUTE_REVERSIBLE", impact_level="LOW")
            proof = rt.control.evaluate(event)
            result = rt.rights.compile(event, proof.state)
            self.assertEqual(result.mode, "EXECUTE_REVERSIBLE")


if __name__ == "__main__": unittest.main()
