import tempfile
import unittest
from pathlib import Path

from common import make_event, make_runtime


class HumanControlTests(unittest.TestCase):
    def test_proven_when_all_tests_pass(self):
        with tempfile.TemporaryDirectory() as d:
            proof = make_runtime(Path(d)).control.evaluate(make_event())
            self.assertEqual(proof.state, "PROVEN")

    def test_impossible_without_authority(self):
        with tempfile.TemporaryDirectory() as d:
            proof = make_runtime(Path(d)).control.evaluate(make_event(human_authority=False, impact_level="HIGH"))
            self.assertEqual(proof.state, "IMPOSSIBLE")

    def test_untested_missing_timing(self):
        with tempfile.TemporaryDirectory() as d:
            proof = make_runtime(Path(d)).control.evaluate(make_event(harm_latency_seconds=None))
            self.assertEqual(proof.state, "UNTESTED")

    def test_nominal_overloaded_reviewer(self):
        with tempfile.TemporaryDirectory() as d:
            proof = make_runtime(Path(d)).control.evaluate(make_event(reviewer_capacity=False))
            self.assertEqual(proof.state, "NOMINAL")


if __name__ == "__main__": unittest.main()
