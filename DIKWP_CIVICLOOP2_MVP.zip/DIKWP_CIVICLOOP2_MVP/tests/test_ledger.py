import tempfile
import unittest
from pathlib import Path
from dikwp_civicloop.ledger import HashLedger


class LedgerTests(unittest.TestCase):
    def test_hash_chain(self):
        with tempfile.TemporaryDirectory() as d:
            led = HashLedger(Path(d) / "ledger.jsonl")
            led.append({"x": 1})
            led.append({"x": 2})
            self.assertTrue(led.verify())

    def test_tamper_detected(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "ledger.jsonl"
            led = HashLedger(path)
            led.append({"x": 1})
            path.write_text(path.read_text().replace('"x": 1', '"x": 9'), encoding="utf-8")
            self.assertFalse(led.verify())


if __name__ == "__main__": unittest.main()
