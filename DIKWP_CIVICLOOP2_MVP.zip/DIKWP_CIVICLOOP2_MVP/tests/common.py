from __future__ import annotations

import json
import tempfile
from pathlib import Path

from dikwp_civicloop.models import ActorPassport, DecisionEvent
from dikwp_civicloop.policy import PolicyProfileSet
from dikwp_civicloop.runtime import CivicLoopRuntime

ROOT = Path(__file__).resolve().parents[1]


def make_event(**overrides):
    base = dict(
        event_id="test-1", scenario_id="test", domain="employment", action_type="recommend",
        impact_level="MEDIUM", affected_party="test_group", requested_mode="PROPOSE",
        actor_id="test_agent", description="test", data_sources=["test"], evidence_quality=.8,
        uncertainty=.2, human_notice_seconds=60.0, harm_latency_seconds=600.0,
        override_latency_seconds=30.0, human_authority=True, reviewer_capacity=True,
        reviewer_independence=True, comprehensible_notice=True, reversible=True,
        recovery_plan=True, traceable=True, alternative_non_ai_path=True,
        appeal_available=True, user_consent=True, benefit_access=.7,
        benefit_capability=.7, benefit_outcome=.7, benefit_voice=.7,
        benefit_value_capture=.7, externality_risk=.2, self_modifying=False,
        physical_world=False, critical_service=False, final_adverse_decision=False,
        metadata={"responsible_party": "test_operator"},
    )
    base.update(overrides)
    return DecisionEvent(**base)


def make_runtime(tmp: Path):
    profiles = PolicyProfileSet.from_directory(ROOT / "policy_profiles")
    return CivicLoopRuntime(profiles, tmp / "ledger.jsonl")


def passport():
    return ActorPassport(
        actor_id="test_agent", actor_type="test", operator="test_operator",
        deployer="test_deployer", accountable_party="test_accountable",
        affected_groups=["test_group"],
    )
