import tempfile
import unittest
from pathlib import Path

from common import make_event, make_runtime


class InclusionRepairTests(unittest.TestCase):
    def test_inclusion_gaps_generate_remedies(self):
        with tempfile.TemporaryDirectory() as d:
            inc = make_runtime(Path(d)).inclusion.evaluate(make_event(benefit_access=.3, benefit_voice=.2))
            self.assertTrue(inc.gaps)
            self.assertTrue(inc.required_remedies)

    def test_critical_failure_opens_repair_ticket(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            event = make_event(critical_service=True, impact_level="CRITICAL", human_authority=False)
            control = rt.control.evaluate(event)
            rights = rt.rights.compile(event, control.state)
            ticket = rt.repair.maybe_open(event, rights, control)
            self.assertIsNotNone(ticket)
            self.assertEqual(ticket.severity, "S3")


if __name__ == "__main__": unittest.main()
