import unittest
from common import make_event
from dikwp_civicloop.mesh import MeshRuntime


class MeshTests(unittest.TestCase):
    def test_full_25_pair_coverage(self):
        mesh = MeshRuntime()
        traces = mesh.trace_event(make_event())
        self.assertEqual(len(traces), 25)
        self.assertEqual(mesh.coverage(traces), 1.0)
        self.assertIn(("P", "D"), {(t.source_type, t.target_type) for t in traces})
        self.assertIn(("D", "P"), {(t.source_type, t.target_type) for t in traces})

    def test_purpose_not_privileged(self):
        traces = MeshRuntime().trace_event(make_event())
        pairs = {(t.source_type, t.target_type) for t in traces}
        self.assertIn(("W", "P"), pairs)
        self.assertIn(("D", "P"), pairs)
        self.assertIn(("P", "P"), pairs)


if __name__ == "__main__": unittest.main()
