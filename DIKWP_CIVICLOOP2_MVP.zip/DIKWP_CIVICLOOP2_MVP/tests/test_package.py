import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PackageTests(unittest.TestCase):
    def test_schema_and_profile_presence(self):
        self.assertGreaterEqual(len(list((ROOT / "schemas").glob("*.json"))), 9)
        self.assertGreaterEqual(len(list((ROOT / "policy_profiles").glob("*.json"))), 5)
        for p in (ROOT / "schemas").glob("*.json"):
            json.loads(p.read_text(encoding="utf-8"))

    def test_synthetic_events_count(self):
        events = json.loads((ROOT / "examples" / "synthetic_decision_events.json").read_text(encoding="utf-8"))
        self.assertEqual(len(events), 180)


if __name__ == "__main__": unittest.main()
