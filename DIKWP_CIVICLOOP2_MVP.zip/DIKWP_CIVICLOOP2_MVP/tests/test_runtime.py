import tempfile
import unittest
from pathlib import Path

from common import make_event, make_runtime, passport


class RuntimeTests(unittest.TestCase):
    def test_assessment_receipt_and_hash(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            result = rt.assess(make_event(), passport())
            self.assertTrue(result.receipt.record_hash)
            self.assertTrue(rt.ledger.verify())

    def test_self_modify_without_authority_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            rt = make_runtime(Path(d))
            event = make_event(action_type="self_modify", self_modifying=True, human_authority=False, traceable=False, reversible=False, recovery_plan=False)
            result = rt.assess(event, passport())
            self.assertIn(result.rights_result.mode, {"BLOCK", "FREEZE_RECOVER"})
            self.assertTrue(result.rule_patches)


if __name__ == "__main__": unittest.main()
