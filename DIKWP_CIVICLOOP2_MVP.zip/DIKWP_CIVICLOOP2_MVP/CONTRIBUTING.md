# Contributing

Contributions are welcome through issues and pull requests.

Every material change should include:

1. the action-specific problem and affected parties;
2. the DIKWP×DIKWP transformations touched;
3. a test or counterexample;
4. backward-compatibility and rollback notes;
5. security, rights and inclusion implications;
6. whether a local policy profile rather than the core runtime should change.

The project rewards reproducible counterexamples. A change that proves a control claim wrong is at least as valuable as a new feature.
