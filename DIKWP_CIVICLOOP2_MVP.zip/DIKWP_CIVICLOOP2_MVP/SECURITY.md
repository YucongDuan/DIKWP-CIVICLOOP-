# Security policy

Please report vulnerabilities privately to the maintainers before public disclosure. High-priority issues include:

- bypass of `BLOCK`, `HOLD`, `REQUIRE_HUMAN`, or `FREEZE_RECOVER` modes;
- forged actor identity, authority, receipt, or ledger record;
- action execution outside a declared permission boundary;
- hidden model/tool changes that evade traceability;
- denial of appeal, rollback, export, or non-AI alternatives;
- prompt injection or data poisoning that changes a high-impact decision;
- a policy profile that silently expands autonomy.

No real personal, medical, employment, benefit or financial data should be attached to a public issue.
