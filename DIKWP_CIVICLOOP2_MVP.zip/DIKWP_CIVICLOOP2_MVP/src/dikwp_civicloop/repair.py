from __future__ import annotations

from datetime import datetime, timezone

from .models import AppealRepairTicket, DecisionEvent, DecisionRightsResult, HumanControlProof


class AppealRepairEngine:
    def maybe_open(
        self,
        event: DecisionEvent,
        rights: DecisionRightsResult,
        control: HumanControlProof,
    ) -> AppealRepairTicket | None:
        needs_ticket = (
            rights.mode in {"BLOCK", "FREEZE_RECOVER"}
            or event.final_adverse_decision
            or control.state == "IMPOSSIBLE"
            or event.externality_risk > 0.7
        )
        if not needs_ticket:
            return None

        if event.critical_service or event.impact_level == "CRITICAL":
            severity = "S3"
            due = 4
        elif event.impact_level == "HIGH" or event.final_adverse_decision:
            severity = "S2"
            due = 24
        else:
            severity = "S1"
            due = 72

        restore = []
        if event.critical_service:
            restore.append("优先恢复原有服务或人工通道，不等待模型原因调查结束。")
        if event.final_adverse_decision:
            restore.append("暂停不利结果生效并保留原资格、原状态或临时权益。")
        if rights.mode == "FREEZE_RECOVER":
            restore.append("冻结相关智能体权限并回滚至最后一个经验证安全状态。")
        if not restore:
            restore.append("通知受影响者并提供临时人工复核。")

        investigation = [
            "保存模型、工具、数据、权限和操作链的不可变快照。",
            "由非原操作者复核证据、意图、规则和人类控制证明。",
            "检查是否存在数据偏差、提示注入、权限越界、指标替代或接口失败。",
            "发布可理解的结论、修复措施和是否需要规则补丁。",
        ]
        repair = [
            "纠正记录与后续模型输入，避免错误被持续学习。",
            "对实际损失启动补偿、服务恢复或机会恢复。",
            "允许受影响者导出材料并申请再次独立复核。",
        ]
        return AppealRepairTicket(
            ticket_id=f"AR-{event.event_id}",
            event_id=event.event_id,
            severity=severity,
            status="OPEN",
            immediate_rights_restoration=restore,
            investigation_steps=investigation,
            compensation_or_repair=repair,
            due_hours=due,
            responsible_party=event.metadata.get("responsible_party", "named_domain_operator"),
            generated_at=datetime.now(timezone.utc).isoformat(),
        )
