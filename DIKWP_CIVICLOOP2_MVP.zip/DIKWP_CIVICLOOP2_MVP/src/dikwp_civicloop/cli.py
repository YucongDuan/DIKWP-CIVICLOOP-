from __future__ import annotations

import argparse
import json
import os
import random
from pathlib import Path
from typing import Any, Dict, List

from .dashboard import render_dashboard
from .models import DecisionEvent
from .policy import PolicyProfileSet
from .runtime import CivicLoopRuntime, load_events, load_passports


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="DIKWP-CIVICLOOP² reference runtime")
    p.add_argument("--root", type=Path, default=None, help="Project root")
    p.add_argument("--events", type=Path, default=None)
    p.add_argument("--passports", type=Path, default=None)
    p.add_argument("--profiles", type=Path, default=None)
    p.add_argument("--out", type=Path, default=None)
    return p


def main(argv: List[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = args.root or Path(os.environ.get("CIVICLOOP_ROOT", Path.cwd()))
    events_path = args.events or root / "examples" / "synthetic_decision_events.json"
    passports_path = args.passports or root / "examples" / "actor_passports.json"
    profiles_dir = args.profiles or root / "policy_profiles"
    out = args.out or root / "outputs"
    out.mkdir(parents=True, exist_ok=True)

    ledger_path = out / "decision_ledger.jsonl"
    if ledger_path.exists():
        ledger_path.unlink()

    profiles = PolicyProfileSet.from_directory(profiles_dir)
    runtime = CivicLoopRuntime(profiles, ledger_path)
    events = load_events(events_path)
    passports = load_passports(passports_path)
    results = runtime.assess_many(events, passports)
    summary = runtime.summarize(results, runtime.ledger.verify())

    (out / "assessments.json").write_text(
        json.dumps([r.to_dict() for r in results], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "decision_receipts.json").write_text(
        json.dumps([r.receipt.to_dict() for r in results], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "appeal_repair_tickets.json").write_text(
        json.dumps([r.appeal_ticket.to_dict() for r in results if r.appeal_ticket], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "ethical_rule_patches.json").write_text(
        json.dumps([p.to_dict() for r in results for p in r.rule_patches], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    render_dashboard(summary, results, out / "dashboard.html")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
