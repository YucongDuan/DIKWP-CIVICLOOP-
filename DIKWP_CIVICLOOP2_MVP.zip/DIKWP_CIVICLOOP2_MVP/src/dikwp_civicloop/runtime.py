from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Any

from .decision_rights import DecisionRightsCompiler
from .human_control import MeaningfulHumanControlEvaluator
from .inclusion import InclusionBenefitEvaluator
from .ledger import HashLedger
from .mesh import MeshRuntime
from .models import ActorPassport, DecisionEvent, RuntimeAssessment
from .policy import PolicyProfileSet
from .receipts import ReceiptFactory
from .repair import AppealRepairEngine
from .rules import EthicalRulePatchEngine


class CivicLoopRuntime:
    def __init__(self, profiles: PolicyProfileSet, ledger_path: Path):
        self.profiles = profiles
        self.control = MeaningfulHumanControlEvaluator()
        self.rights = DecisionRightsCompiler(profiles)
        self.inclusion = InclusionBenefitEvaluator()
        self.repair = AppealRepairEngine()
        self.rules = EthicalRulePatchEngine()
        self.mesh = MeshRuntime()
        self.receipts = ReceiptFactory()
        self.ledger = HashLedger(ledger_path)

    def assess(self, event: DecisionEvent, passport: ActorPassport) -> RuntimeAssessment:
        control = self.control.evaluate(event)
        rights = self.rights.compile(event, control.state)
        inclusion = self.inclusion.evaluate(event)
        ticket = self.repair.maybe_open(event, rights, control)
        patches = self.rules.propose(event, rights.mode, inclusion)
        traces = self.mesh.trace_event(event)
        receipt = self.receipts.build(event, rights, control, passport.accountable_party)
        appended = self.ledger.append({
            "record_type": "decision_receipt",
            "receipt": receipt.to_dict(),
            "control_state": control.state,
            "runtime_mode": rights.mode,
            "profile_hits": rights.profile_hits,
        })
        receipt.previous_hash = appended["previous_hash"]
        receipt.record_hash = appended["record_hash"]
        return RuntimeAssessment(
            event=event,
            control_proof=control,
            rights_result=rights,
            receipt=receipt,
            inclusion=inclusion,
            appeal_ticket=ticket,
            rule_patches=patches,
            mesh_traces=traces,
        )

    def assess_many(self, events: Iterable[DecisionEvent], passports: Dict[str, ActorPassport]) -> List[RuntimeAssessment]:
        out: List[RuntimeAssessment] = []
        for event in events:
            if event.actor_id not in passports:
                raise KeyError(f"No ActorPassport for {event.actor_id}")
            out.append(self.assess(event, passports[event.actor_id]))
        return out

    @staticmethod
    def summarize(results: Iterable[RuntimeAssessment], ledger_valid: bool) -> Dict[str, Any]:
        results = list(results)
        modes = Counter(r.rights_result.mode for r in results)
        control = Counter(r.control_proof.state for r in results)
        domains = Counter(r.event.domain for r in results)
        tickets = Counter(r.appeal_ticket.severity for r in results if r.appeal_ticket)
        profile_hits = Counter(p for r in results for p in r.rights_result.profile_hits)
        gap_counts = Counter(g.split("（")[0] for r in results for g in r.inclusion.gaps)
        mesh_pairs = {(t.source_type, t.target_type) for r in results for t in r.mesh_traces}
        avg = lambda attr: round(sum(getattr(r.event, attr) for r in results) / max(len(results), 1), 4)
        return {
            "events": len(results),
            "runtime_modes": dict(modes),
            "control_states": dict(control),
            "domains": dict(domains),
            "appeal_severities": dict(tickets),
            "profile_hits": dict(profile_hits),
            "inclusion_gap_counts": dict(gap_counts),
            "rule_patches": sum(len(r.rule_patches) for r in results),
            "appeal_tickets": sum(1 for r in results if r.appeal_ticket),
            "mesh_coverage": round(len(mesh_pairs) / 25.0, 4),
            "ledger_valid": ledger_valid,
            "average_evidence_quality": avg("evidence_quality"),
            "average_uncertainty": avg("uncertainty"),
            "average_externality_risk": avg("externality_risk"),
            "average_inclusion": {
                "access": avg("benefit_access"),
                "capability": avg("benefit_capability"),
                "outcome": avg("benefit_outcome"),
                "voice": avg("benefit_voice"),
                "value_capture": avg("benefit_value_capture"),
            },
        }


def load_events(path: Path) -> List[DecisionEvent]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    return [DecisionEvent(**item) for item in raw]


def load_passports(path: Path) -> Dict[str, ActorPassport]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    actors = [ActorPassport(**item) for item in raw]
    return {a.actor_id: a for a in actors}
