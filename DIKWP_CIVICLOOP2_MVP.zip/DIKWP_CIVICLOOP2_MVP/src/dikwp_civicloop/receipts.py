from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import List

from .models import DecisionEvent, DecisionReceipt, DecisionRightsResult, HumanControlProof


class ReceiptFactory:
    def build(
        self,
        event: DecisionEvent,
        rights: DecisionRightsResult,
        control: HumanControlProof,
        responsible_party: str,
    ) -> DecisionReceipt:
        evidence_summary: List[str] = []
        evidence_summary.append(f"证据质量={event.evidence_quality:.2f}")
        evidence_summary.append(f"不确定性={event.uncertainty:.2f}")
        evidence_summary.append(f"人类控制状态={control.state}")
        if event.data_sources:
            evidence_summary.append("来源=" + "、".join(event.data_sources[:4]))

        if rights.mode in {"OBSERVE", "ADVISE", "PROPOSE"}:
            agent_role = "观察、分析或提出方案，不直接改变权利与现实资源"
        elif rights.mode == "EXECUTE_REVERSIBLE":
            agent_role = "在明确权限、限额和回滚条件下执行可逆动作"
        elif rights.mode == "REQUIRE_HUMAN":
            agent_role = "准备证据和建议，等待具名人类作出最终决定"
        elif rights.mode in {"HOLD", "BLOCK"}:
            agent_role = "停止推进并保存证据"
        else:
            agent_role = "冻结权限、恢复安全状态与受影响服务"

        human_role = {
            "OBSERVE": "审阅输出并决定是否进入下一阶段",
            "ADVISE": "对建议负责，不得把模型输出伪装为最终决定",
            "PROPOSE": "比较方案、补充反证并签署授权",
            "EXECUTE_REVERSIBLE": "持续监测，必要时暂停或回滚",
            "REQUIRE_HUMAN": "具名决策、说明理由并承担责任",
            "HOLD": "补齐证据和控制条件",
            "BLOCK": "不得绕过阻断；如需重启必须重新授权",
            "FREEZE_RECOVER": "先恢复服务与权利，再组织独立调查",
        }[rights.mode]

        return DecisionReceipt(
            receipt_id=f"DR-{event.event_id}",
            event_id=event.event_id,
            scenario_id=event.scenario_id,
            affected_party=event.affected_party,
            domain=event.domain,
            action_type=event.action_type,
            runtime_mode=rights.mode,
            agent_role=agent_role,
            human_role=human_role,
            evidence_summary=evidence_summary,
            uncertainty=event.uncertainty,
            reasons=rights.reasons + control.blocking_reasons,
            data_use_summary=event.data_sources,
            appeal_channel="人工复核与修复工单" if event.appeal_available else "当前未建立；该缺口已进入阻断或规则补丁",
            rollback_channel="自动/人工回滚" if event.reversible or event.recovery_plan else "无可验证回滚；不得自动执行",
            responsible_party=responsible_party,
            expiry=(date.today() + timedelta(days=30)).isoformat(),
            generated_at=datetime.now(timezone.utc).isoformat(),
        )
