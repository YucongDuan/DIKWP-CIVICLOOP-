from __future__ import annotations

from datetime import date, timedelta
from typing import List

from .models import DecisionEvent, EthicalRulePatch, InclusionBenefitRecord


class EthicalRulePatchEngine:
    """Propose reversible, expiring rule changes rather than declaring final ethics."""

    def propose(self, event: DecisionEvent, mode: str, inclusion: InclusionBenefitRecord) -> List[EthicalRulePatch]:
        patches: List[EthicalRulePatch] = []
        sunset = (date.today() + timedelta(days=180)).isoformat()

        if event.final_adverse_decision and mode in {"BLOCK", "REQUIRE_HUMAN", "FREEZE_RECOVER"}:
            patches.append(EthicalRulePatch(
                patch_id=f"ERP-{event.event_id}-HUMANFINAL",
                source_event_id=event.event_id,
                profile="contextual_high_impact",
                change_type="tighten_decision_right",
                before_rule="AI output may directly produce a final adverse result.",
                proposed_rule="AI may gather evidence and recommend; a named human must issue the final adverse decision and receipt.",
                evidence=["final_adverse_decision", f"runtime_mode={mode}"],
                affected_groups=[event.affected_party],
                review_required=True,
                sunset_date=sunset,
                rollback_condition="Independent review shows no material rights benefit or an excessive access burden.",
            ))
        if not event.alternative_non_ai_path and event.critical_service:
            patches.append(EthicalRulePatch(
                patch_id=f"ERP-{event.event_id}-ALTCHANNEL",
                source_event_id=event.event_id,
                profile="critical_service",
                change_type="add_service_continuity",
                before_rule="The AI-enabled channel is the only practical service route.",
                proposed_rule="Maintain an operational human-assisted or offline alternative with published service-level targets.",
                evidence=["critical_service", "alternative_non_ai_path=false"],
                affected_groups=[event.affected_party],
                review_required=True,
                sunset_date=sunset,
                rollback_condition="A better universally accessible alternative is independently verified.",
            ))
        if inclusion.voice_control < 0.55:
            patches.append(EthicalRulePatch(
                patch_id=f"ERP-{event.event_id}-VOICE",
                source_event_id=event.event_id,
                profile="inclusive_governance",
                change_type="add_affected_party_power",
                before_rule="Metrics and thresholds are changed by operators only.",
                proposed_rule="Any material metric or threshold change must include affected-party review and published dissent.",
                evidence=[f"voice_control={inclusion.voice_control:.2f}"],
                affected_groups=[event.affected_party],
                review_required=True,
                sunset_date=sunset,
                rollback_condition="Participation is shown to be non-representative and a superior mechanism is approved.",
            ))
        if event.self_modifying:
            patches.append(EthicalRulePatch(
                patch_id=f"ERP-{event.event_id}-METARULE",
                source_event_id=event.event_id,
                profile="self_modification",
                change_type="restrict_meta_adaptation",
                before_rule="The agent may change its own decision or reward rules during deployment.",
                proposed_rule="Self-modification remains in shadow mode until independently reproduced, signed and reversible.",
                evidence=["self_modifying=true"],
                affected_groups=[event.affected_party, "operators", "future users"],
                review_required=True,
                sunset_date=sunset,
                rollback_condition="A conformance suite proves bounded, traceable and reversible meta-adaptation.",
            ))
        return patches
