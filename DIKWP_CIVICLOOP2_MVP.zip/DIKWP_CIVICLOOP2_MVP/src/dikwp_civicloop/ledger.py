from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List


class HashLedger:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def canonical(data: Dict[str, Any]) -> str:
        return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    @classmethod
    def digest(cls, data: Dict[str, Any]) -> str:
        return hashlib.sha256(cls.canonical(data).encode("utf-8")).hexdigest()

    def append(self, record: Dict[str, Any]) -> Dict[str, Any]:
        previous_hash = "GENESIS"
        if self.path.exists() and self.path.stat().st_size:
            lines = self.path.read_text(encoding="utf-8").splitlines()
            previous_hash = json.loads(lines[-1])["record_hash"]
        payload = dict(record)
        payload["previous_hash"] = previous_hash
        payload["record_hash"] = self.digest({k: v for k, v in payload.items() if k != "record_hash"})
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        return payload

    def read(self) -> List[Dict[str, Any]]:
        if not self.path.exists():
            return []
        return [json.loads(line) for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()]

    def verify(self) -> bool:
        prev = "GENESIS"
        for record in self.read():
            if record.get("previous_hash") != prev:
                return False
            expected = self.digest({k: v for k, v in record.items() if k != "record_hash"})
            if expected != record.get("record_hash"):
                return False
            prev = record["record_hash"]
        return True
