from __future__ import annotations

from typing import List

from .models import DecisionEvent, DecisionRightsResult
from .policy import PolicyProfileSet


IMPACT_ORDER = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


class DecisionRightsCompiler:
    """Compile action-specific authority instead of defining autonomy in the abstract."""

    def __init__(self, profiles: PolicyProfileSet):
        self.profiles = profiles

    def compile(self, event: DecisionEvent, control_state: str) -> DecisionRightsResult:
        mode = event.requested_mode
        permissions: List[str] = []
        prohibitions: List[str] = []
        approvals: List[str] = []
        reasons: List[str] = []
        profile_hits: List[str] = []

        applicable = self.profiles.applicable(event.domain)
        for profile in applicable:
            profile_hits.append(profile.profile_id)
            if event.action_type in profile.prohibited_autonomous_actions:
                prohibitions.append(f"{profile.profile_id}: autonomous {event.action_type} is prohibited")
            if profile.require_final_human_decision and event.final_adverse_decision:
                approvals.append(f"{profile.profile_id}: named human final decision")
            if profile.require_appeal and not event.appeal_available:
                prohibitions.append(f"{profile.profile_id}: no appeal or repair channel")
            if profile.require_traceability and not event.traceable:
                prohibitions.append(f"{profile.profile_id}: action is not traceable")
            if profile.require_non_ai_alternative and event.critical_service and not event.alternative_non_ai_path:
                prohibitions.append(f"{profile.profile_id}: critical service lacks non-AI alternative")
            if IMPACT_ORDER[event.impact_level] > IMPACT_ORDER.get(profile.max_autonomy_impact, 1):
                approvals.append(f"{profile.profile_id}: impact exceeds permitted autonomy")

        hard_rights_failures = []
        if event.final_adverse_decision and not event.appeal_available:
            hard_rights_failures.append("final adverse decision without appeal")
        if event.critical_service and not event.alternative_non_ai_path:
            hard_rights_failures.append("critical service without practical alternative")
        if event.physical_world and not (event.reversible or event.recovery_plan):
            hard_rights_failures.append("irreversible physical action without recovery plan")
        if event.self_modifying and not (event.traceable and event.human_authority):
            hard_rights_failures.append("self-modification without traceable human authority")
        if not event.user_consent and event.action_type in {"infer", "rank", "allocate", "deny", "transact", "modify"}:
            hard_rights_failures.append("personal impact without valid consent or legal authority")

        if hard_rights_failures:
            mode = "BLOCK"
            prohibitions.extend(hard_rights_failures)
            reasons.append("A rights hard gate failed; aggregate benefits cannot compensate for it.")
        elif control_state == "IMPOSSIBLE":
            if event.critical_service or event.impact_level == "CRITICAL":
                mode = "FREEZE_RECOVER"
                reasons.append("Meaningful human control is impossible for a critical action; freeze and restore service.")
            else:
                mode = "BLOCK"
                reasons.append("Meaningful human control is impossible for the requested action.")
        elif control_state == "UNTESTED":
            mode = "HOLD"
            reasons.append("The evidence needed to prove human control is incomplete.")
        elif control_state == "NOMINAL":
            if event.impact_level in {"HIGH", "CRITICAL"} or approvals:
                mode = "REQUIRE_HUMAN"
                reasons.append("Human control exists only nominally; a named human must decide and sign.")
            elif event.reversible:
                mode = "EXECUTE_REVERSIBLE"
                reasons.append("Only a reversible, bounded action is allowed while control weaknesses are repaired.")
            else:
                mode = "HOLD"
                reasons.append("Control weaknesses and irreversibility require a hold.")
        else:  # PROVEN
            if event.final_adverse_decision or approvals:
                mode = "REQUIRE_HUMAN"
                reasons.append("The system may prepare and recommend, but the final adverse decision remains human.")
            elif event.requested_mode in {"OBSERVE", "ADVISE", "PROPOSE"}:
                mode = event.requested_mode
                reasons.append("The requested low-authority mode is compatible with the proof and profile.")
            elif event.reversible:
                mode = "EXECUTE_REVERSIBLE"
                reasons.append("Bounded execution is permitted with rollback and traceability.")
            else:
                mode = "REQUIRE_HUMAN"
                reasons.append("The action is not reversible; human authorization remains required.")

        if mode in {"OBSERVE", "ADVISE", "PROPOSE"}:
            permissions.extend(["read permitted evidence", "produce reasons and uncertainty", "generate a decision receipt"])
        if mode == "EXECUTE_REVERSIBLE":
            permissions.extend(["execute within explicit scope", "write append-only trace", "invoke rollback"])
        if mode == "REQUIRE_HUMAN":
            permissions.extend(["prepare recommendation", "simulate options", "collect counter-evidence"])
            prohibitions.append("no final execution before named human approval")
        if mode in {"HOLD", "BLOCK", "FREEZE_RECOVER"}:
            permissions.append("preserve evidence and notify responsible parties")
        if mode == "FREEZE_RECOVER":
            permissions.extend(["restore previous safe state", "restore affected service or right"])

        return DecisionRightsResult(
            event_id=event.event_id,
            mode=mode,
            permissions=sorted(set(permissions)),
            prohibitions=sorted(set(prohibitions)),
            required_approvals=sorted(set(approvals)),
            profile_hits=profile_hits,
            reasons=reasons,
        )
