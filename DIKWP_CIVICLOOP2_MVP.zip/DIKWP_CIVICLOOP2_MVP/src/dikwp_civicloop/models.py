from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


DIKWP_TYPES = ("D", "I", "K", "W", "P")
ACTION_MODES = (
    "OBSERVE",
    "ADVISE",
    "PROPOSE",
    "EXECUTE_REVERSIBLE",
    "REQUIRE_HUMAN",
    "HOLD",
    "BLOCK",
    "FREEZE_RECOVER",
)
CONTROL_STATES = ("PROVEN", "NOMINAL", "IMPOSSIBLE", "UNTESTED")


@dataclass
class ActorPassport:
    actor_id: str
    actor_type: str
    operator: str
    deployer: str
    accountable_party: str
    affected_groups: List[str]
    jurisdiction: str = "CN"
    capabilities: List[str] = field(default_factory=list)
    prohibited_claims: List[str] = field(default_factory=list)
    version: str = "1.0"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class IntentField:
    intent_id: str
    driving_intents: List[str]
    protected_continuities: List[str]
    prohibited_outcomes: List[str]
    uncertainties: List[str]
    revision_triggers: List[str]
    observers: List[str]
    scale: str
    time_window: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DecisionEvent:
    event_id: str
    scenario_id: str
    domain: str
    action_type: str
    impact_level: str
    affected_party: str
    requested_mode: str
    actor_id: str
    description: str
    data_sources: List[str]
    evidence_quality: float
    uncertainty: float
    human_notice_seconds: Optional[float]
    harm_latency_seconds: Optional[float]
    override_latency_seconds: Optional[float]
    human_authority: bool
    reviewer_capacity: bool
    reviewer_independence: bool
    comprehensible_notice: bool
    reversible: bool
    recovery_plan: bool
    traceable: bool
    alternative_non_ai_path: bool
    appeal_available: bool
    user_consent: bool
    benefit_access: float
    benefit_capability: float
    benefit_outcome: float
    benefit_voice: float
    benefit_value_capture: float
    externality_risk: float
    self_modifying: bool = False
    physical_world: bool = False
    critical_service: bool = False
    final_adverse_decision: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ControlTest:
    name: str
    passed: Optional[bool]
    observed: Any
    requirement: str
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HumanControlProof:
    event_id: str
    state: str
    tests: List[ControlTest]
    blocking_reasons: List[str]
    evidence_missing: List[str]
    generated_at: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "state": self.state,
            "tests": [t.to_dict() for t in self.tests],
            "blocking_reasons": self.blocking_reasons,
            "evidence_missing": self.evidence_missing,
            "generated_at": self.generated_at,
        }


@dataclass
class DecisionRightsResult:
    event_id: str
    mode: str
    permissions: List[str]
    prohibitions: List[str]
    required_approvals: List[str]
    profile_hits: List[str]
    reasons: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DecisionReceipt:
    receipt_id: str
    event_id: str
    scenario_id: str
    affected_party: str
    domain: str
    action_type: str
    runtime_mode: str
    agent_role: str
    human_role: str
    evidence_summary: List[str]
    uncertainty: float
    reasons: List[str]
    data_use_summary: List[str]
    appeal_channel: str
    rollback_channel: str
    responsible_party: str
    expiry: str
    generated_at: str
    previous_hash: str = ""
    record_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AppealRepairTicket:
    ticket_id: str
    event_id: str
    severity: str
    status: str
    immediate_rights_restoration: List[str]
    investigation_steps: List[str]
    compensation_or_repair: List[str]
    due_hours: int
    responsible_party: str
    generated_at: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InclusionBenefitRecord:
    event_id: str
    affected_party: str
    access: float
    capability: float
    outcome: float
    voice_control: float
    value_capture: float
    gaps: List[str]
    required_remedies: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EthicalRulePatch:
    patch_id: str
    source_event_id: str
    profile: str
    change_type: str
    before_rule: str
    proposed_rule: str
    evidence: List[str]
    affected_groups: List[str]
    review_required: bool
    sunset_date: str
    rollback_condition: str
    status: str = "PROPOSED"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MeshTrace:
    event_id: str
    source_type: str
    target_type: str
    operation: str
    observer: str
    context: str
    provenance: str
    note: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RuntimeAssessment:
    event: DecisionEvent
    control_proof: HumanControlProof
    rights_result: DecisionRightsResult
    receipt: DecisionReceipt
    inclusion: InclusionBenefitRecord
    appeal_ticket: Optional[AppealRepairTicket]
    rule_patches: List[EthicalRulePatch]
    mesh_traces: List[MeshTrace]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event": self.event.to_dict(),
            "control_proof": self.control_proof.to_dict(),
            "rights_result": self.rights_result.to_dict(),
            "receipt": self.receipt.to_dict(),
            "inclusion": self.inclusion.to_dict(),
            "appeal_ticket": self.appeal_ticket.to_dict() if self.appeal_ticket else None,
            "rule_patches": [p.to_dict() for p in self.rule_patches],
            "mesh_traces": [t.to_dict() for t in self.mesh_traces],
        }
