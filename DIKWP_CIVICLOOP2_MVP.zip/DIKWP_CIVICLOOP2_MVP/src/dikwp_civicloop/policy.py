from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Any


class PolicyProfile:
    def __init__(self, raw: Mapping[str, Any]):
        self.raw = dict(raw)
        self.profile_id = str(self.raw["profile_id"])
        self.name = str(self.raw["name"])
        self.domains = set(self.raw.get("domains", ["*"]))
        self.high_impact_actions = set(self.raw.get("high_impact_actions", []))
        self.prohibited_autonomous_actions = set(self.raw.get("prohibited_autonomous_actions", []))
        self.required_controls = list(self.raw.get("required_controls", []))
        self.require_final_human_decision = bool(self.raw.get("require_final_human_decision", False))
        self.require_appeal = bool(self.raw.get("require_appeal", False))
        self.require_traceability = bool(self.raw.get("require_traceability", False))
        self.require_non_ai_alternative = bool(self.raw.get("require_non_ai_alternative", False))
        self.max_autonomy_impact = str(self.raw.get("max_autonomy_impact", "LOW"))
        self.source = str(self.raw.get("source", ""))

    def applies_to(self, domain: str) -> bool:
        return "*" in self.domains or domain in self.domains


class PolicyProfileSet:
    def __init__(self, profiles: Iterable[PolicyProfile]):
        self.profiles = list(profiles)

    @classmethod
    def from_directory(cls, directory: Path) -> "PolicyProfileSet":
        profiles: List[PolicyProfile] = []
        for path in sorted(directory.glob("*.json")):
            profiles.append(PolicyProfile(json.loads(path.read_text(encoding="utf-8"))))
        return cls(profiles)

    def applicable(self, domain: str) -> List[PolicyProfile]:
        return [p for p in self.profiles if p.applies_to(domain)]

    def by_id(self) -> Dict[str, PolicyProfile]:
        return {p.profile_id: p for p in self.profiles}
