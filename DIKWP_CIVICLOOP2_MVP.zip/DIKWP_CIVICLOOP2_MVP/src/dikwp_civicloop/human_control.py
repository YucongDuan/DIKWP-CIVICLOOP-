from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from .models import ControlTest, DecisionEvent, HumanControlProof


def _test(name: str, passed: Optional[bool], observed, requirement: str, rationale: str) -> ControlTest:
    return ControlTest(name=name, passed=passed, observed=observed, requirement=requirement, rationale=rationale)


class MeaningfulHumanControlEvaluator:
    """Evaluate whether human control is operationally meaningful for one action.

    The evaluator deliberately avoids a universal definition of human control. It compiles
    a context-specific proof from intervention time, authority, comprehension, capacity,
    independence, reversibility, traceability, alternatives and appeal/repair.
    """

    def evaluate(self, event: DecisionEvent) -> HumanControlProof:
        tests: List[ControlTest] = []
        missing: List[str] = []
        blocking: List[str] = []

        notice_known = event.human_notice_seconds is not None
        if not notice_known:
            missing.append("human_notice_seconds")
        tests.append(_test(
            "awareness",
            event.comprehensible_notice if notice_known else None,
            {"notice_seconds": event.human_notice_seconds, "comprehensible": event.comprehensible_notice},
            "The responsible human knows what the system is about to do and why.",
            "A hidden or unintelligible action cannot be meaningfully controlled.",
        ))

        timing_pass: Optional[bool]
        if event.harm_latency_seconds is None or event.override_latency_seconds is None:
            timing_pass = None
            missing.extend([
                name for name, value in (
                    ("harm_latency_seconds", event.harm_latency_seconds),
                    ("override_latency_seconds", event.override_latency_seconds),
                ) if value is None
            ])
        elif event.harm_latency_seconds <= 0:
            timing_pass = False
        else:
            safety_margin = 0.75 if event.impact_level in {"HIGH", "CRITICAL"} else 0.95
            timing_pass = event.override_latency_seconds <= event.harm_latency_seconds * safety_margin
        tests.append(_test(
            "intervention_window",
            timing_pass,
            {"harm_latency_seconds": event.harm_latency_seconds, "override_latency_seconds": event.override_latency_seconds},
            "Override and recovery can occur before material harm becomes difficult to reverse.",
            "A nominal stop button is not control when harm occurs faster than humans can intervene.",
        ))

        tests.append(_test(
            "actual_authority",
            event.human_authority,
            event.human_authority,
            "The human has legal and technical power to change, stop or reject the action.",
            "Review without authority is observation, not control.",
        ))
        tests.append(_test(
            "review_capacity",
            event.reviewer_capacity,
            event.reviewer_capacity,
            "The reviewer has enough time, competence and workload capacity to exercise judgment.",
            "Rubber-stamp review caused by overload cannot satisfy meaningful control.",
        ))
        tests.append(_test(
            "review_independence",
            event.reviewer_independence,
            event.reviewer_independence,
            "The reviewer can disagree without retaliation or automatic override.",
            "A reviewer subordinated to the same metric or operator cannot reliably correct the system.",
        ))

        recovery_ok = event.reversible or event.recovery_plan
        tests.append(_test(
            "reversibility_and_recovery",
            recovery_ok,
            {"reversible": event.reversible, "recovery_plan": event.recovery_plan},
            "The system can roll back the action or restore rights and service after error.",
            "For irreversible actions, prevention thresholds must be materially higher.",
        ))
        tests.append(_test(
            "traceability",
            event.traceable,
            event.traceable,
            "Identity, evidence, permissions, model/tool versions and actions are recorded.",
            "An untraceable decision cannot be reviewed, attributed or repaired.",
        ))
        tests.append(_test(
            "non_ai_alternative",
            event.alternative_non_ai_path,
            event.alternative_non_ai_path,
            "Affected people retain a practical non-AI or human-assisted route.",
            "A formal opt-out is meaningless if no usable alternative service exists.",
        ))
        tests.append(_test(
            "appeal_and_repair",
            event.appeal_available,
            event.appeal_available,
            "An affected party can challenge the result and trigger timely restoration or correction.",
            "Human control also exists after a decision through contestability and repair.",
        ))

        failed = [t.name for t in tests if t.passed is False]
        unknown = [t.name for t in tests if t.passed is None]

        if not event.human_authority:
            blocking.append("No human actor has actual authority to override or reject the action.")
        if timing_pass is False and event.impact_level in {"HIGH", "CRITICAL"}:
            blocking.append("Harm can materialize faster than human intervention.")
        if event.final_adverse_decision and not event.appeal_available:
            blocking.append("A final adverse decision has no meaningful appeal channel.")
        if event.critical_service and not event.alternative_non_ai_path:
            blocking.append("Critical service depends on the AI path without a practical alternative.")
        if event.self_modifying and not (event.human_authority and event.traceable and recovery_ok):
            blocking.append("Self-modification lacks simultaneous authority, traceability and recovery controls.")

        if unknown:
            state = "UNTESTED"
        elif blocking:
            state = "IMPOSSIBLE"
        elif not failed:
            state = "PROVEN"
        else:
            state = "NOMINAL"

        return HumanControlProof(
            event_id=event.event_id,
            state=state,
            tests=tests,
            blocking_reasons=blocking,
            evidence_missing=missing,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )
