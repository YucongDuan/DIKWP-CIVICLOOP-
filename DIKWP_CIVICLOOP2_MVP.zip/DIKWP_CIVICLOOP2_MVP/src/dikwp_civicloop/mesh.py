from __future__ import annotations

from itertools import product
from typing import Iterable, List

from .models import DIKWP_TYPES, DecisionEvent, MeshTrace


OPERATIONS = {
    ("D", "D"): "validate_or_remeasure",
    ("D", "I"): "extract_action_relevant_difference",
    ("D", "K"): "update_competing_causal_models",
    ("D", "W"): "surface_harm_or_benefit_evidence",
    ("D", "P"): "revise_or_suspend_intent",
    ("I", "D"): "request_discriminating_observation",
    ("I", "I"): "reframe_relationship_pattern",
    ("I", "K"): "test_relationship_as_model",
    ("I", "W"): "expose_distributional_consequence",
    ("I", "P"): "open_new_action_question",
    ("K", "D"): "derive_required_measurement",
    ("K", "I"): "derive_testable_signal",
    ("K", "K"): "compare_or_repair_model",
    ("K", "W"): "estimate_long_term_consequence",
    ("K", "P"): "alter_action_strategy",
    ("W", "D"): "require_rights_or_welfare_metric",
    ("W", "I"): "reinterpret_difference_by_affected_group",
    ("W", "K"): "challenge_model_scope_or_normativity",
    ("W", "W"): "negotiate_conflicting_values",
    ("W", "P"): "block_or_redirect_intent",
    ("P", "D"): "select_observation_for_intent",
    ("P", "I"): "prioritize_difference_for_action",
    ("P", "K"): "commission_model_for_decision",
    ("P", "W"): "expose_who_bears_risk_or_benefit",
    ("P", "P"): "split_merge_pause_or_sunset_intent",
}


class MeshRuntime:
    """Create a complete DIKWP×DIKWP trace without imposing a hierarchy."""

    @staticmethod
    def all_pairs() -> List[tuple[str, str]]:
        return list(product(DIKWP_TYPES, repeat=2))

    def trace_event(self, event: DecisionEvent, observer: str = "multi_actor_panel") -> List[MeshTrace]:
        traces: List[MeshTrace] = []
        for source, target in self.all_pairs():
            note = self._note(event, source, target)
            traces.append(MeshTrace(
                event_id=event.event_id,
                source_type=source,
                target_type=target,
                operation=OPERATIONS[(source, target)],
                observer=observer,
                context=f"{event.domain}:{event.action_type}:{event.impact_level}",
                provenance=",".join(event.data_sources) if event.data_sources else "unavailable",
                note=note,
            ))
        return traces

    def _note(self, event: DecisionEvent, source: str, target: str) -> str:
        if (source, target) == ("P", "D"):
            return f"The requested action '{event.action_type}' determines which evidence must be collected before execution."
        if (source, target) == ("D", "P"):
            return "Observed harm, exclusion or uncertainty can suspend the original intent."
        if (source, target) == ("W", "D"):
            return "Affected-party rights require measurement beyond task success and cost reduction."
        if (source, target) == ("P", "P"):
            return "The original intent may be split into advise, reversible execution and prohibited final-decision intents."
        if (source, target) == ("W", "P"):
            return "Where rights and task objectives conflict, the task intent is revised rather than treated as supreme."
        return f"Apply {OPERATIONS[(source, target)]} under the event-specific observer, scale and provenance."

    @staticmethod
    def coverage(traces: Iterable[MeshTrace]) -> float:
        observed = {(t.source_type, t.target_type) for t in traces}
        return len(observed) / 25.0
