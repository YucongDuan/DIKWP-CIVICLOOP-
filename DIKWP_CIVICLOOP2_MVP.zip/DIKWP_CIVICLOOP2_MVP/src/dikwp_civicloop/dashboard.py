from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Iterable, Mapping, Any

from .models import RuntimeAssessment


CSS = """
:root{--ink:#172b36;--muted:#5d6b75;--line:#d7e0e5;--soft:#f3f7f8;--accent:#1d6575;--warn:#8a5b1f;--bad:#8b3d45;--good:#2f6f5e}
*{box-sizing:border-box}body{margin:0;background:#eef3f5;color:var(--ink);font-family:Inter,"Noto Sans SC",Arial,sans-serif;line-height:1.55}
header{background:#173f4f;color:white;padding:34px 6vw 26px}header h1{margin:0 0 8px;font-size:34px}header p{margin:0;max-width:1000px;color:#d9e7eb}
main{max-width:1240px;margin:auto;padding:26px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px}.card{background:white;border:1px solid var(--line);border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.04)}.metric{font-size:28px;font-weight:750}.muted{color:var(--muted);font-size:13px}
section{margin:24px 0}h2{font-size:23px;margin:0 0 12px}h3{font-size:17px}.tag{display:inline-block;border:1px solid var(--line);padding:3px 8px;border-radius:999px;margin:2px;font-size:12px;background:var(--soft)}
table{width:100%;border-collapse:collapse;background:white;border:1px solid var(--line)}th,td{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;text-align:left;font-size:13px}th{background:#173f4f;color:white;position:sticky;top:0}.scroll{overflow:auto;max-height:620px;border-radius:10px}
.PROVEN{color:var(--good);font-weight:700}.NOMINAL{color:var(--warn);font-weight:700}.IMPOSSIBLE,.BLOCK,.FREEZE_RECOVER{color:var(--bad);font-weight:700}.UNTESTED,.HOLD,.REQUIRE_HUMAN{color:var(--warn);font-weight:700}.EXECUTE_REVERSIBLE{color:var(--good);font-weight:700}
.bar{height:10px;background:#e6ecef;border-radius:8px;overflow:hidden}.bar>span{display:block;height:100%;background:#5c8793}.small{font-size:12px}.notice{border-left:5px solid var(--accent);background:white;padding:14px 16px;border-radius:8px}
footer{padding:30px;color:var(--muted);text-align:center}
"""


def _esc(v: Any) -> str:
    return html.escape(str(v))


def _metric_card(label: str, value: Any, note: str = "") -> str:
    return f'<div class="card"><div class="muted">{_esc(label)}</div><div class="metric">{_esc(value)}</div><div class="muted">{_esc(note)}</div></div>'


def render_dashboard(summary: Mapping[str, Any], results: Iterable[RuntimeAssessment], output: Path) -> None:
    results = list(results)
    rows = []
    for r in results:
        gaps = "；".join(r.inclusion.gaps[:2]) or "—"
        reasons = "；".join((r.rights_result.reasons + r.control_proof.blocking_reasons)[:2]) or "—"
        rows.append(
            "<tr>"
            f"<td>{_esc(r.event.event_id)}</td>"
            f"<td>{_esc(r.event.domain)}</td>"
            f"<td>{_esc(r.event.action_type)}</td>"
            f"<td>{_esc(r.event.impact_level)}</td>"
            f"<td class='{_esc(r.control_proof.state)}'>{_esc(r.control_proof.state)}</td>"
            f"<td class='{_esc(r.rights_result.mode)}'>{_esc(r.rights_result.mode)}</td>"
            f"<td>{_esc(reasons)}</td>"
            f"<td>{_esc(gaps)}</td>"
            f"<td>{_esc(r.receipt.record_hash[:12])}</td>"
            "</tr>"
        )

    mode_cards = "".join(_metric_card(k, v) for k, v in sorted(summary["runtime_modes"].items()))
    control_cards = "".join(_metric_card(k, v) for k, v in sorted(summary["control_states"].items()))
    inclusion = summary["average_inclusion"]
    inclusion_cards = "".join(
        f'<div class="card"><div class="muted">{_esc(k)}</div><div class="metric">{v:.2f}</div><div class="bar"><span style="width:{max(0,min(100,v*100)):.0f}%"></span></div></div>'
        for k, v in inclusion.items()
    )

    payload = json.dumps(summary, ensure_ascii=False, indent=2)
    output.write_text(f"""<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>DIKWP-CIVICLOOP² Dashboard</title><style>{CSS}</style></head>
<body><header><h1>DIKWP-CIVICLOOP²</h1><p>实质性人类控制、算法决策可争议、伦理规则演化与普惠收益公共运行时。此页面展示合成案例的机制验证结果，不是现实系统合规认证。</p></header><main>
<div class='notice'><strong>四问到四证：</strong>相处关系证据包 · 实质性控制证明 · 伦理规则补丁 · 普惠收益账本。系统不为“控制、伦理、普惠”给出脱离场景的唯一概念定义，而是对每次具体行动编译可测试证据。</div>
<section><h2>运行摘要</h2><div class='grid'>{_metric_card('合成决策事件',summary['events'])}{_metric_card('DIKWP×DIKWP覆盖',f"{summary['mesh_coverage']*100:.0f}%")}{_metric_card('申诉/修复工单',summary['appeal_tickets'])}{_metric_card('伦理规则补丁',summary['rule_patches'])}{_metric_card('哈希账本','PASS' if summary['ledger_valid'] else 'FAIL')}</div></section>
<section><h2>运行模式</h2><div class='grid'>{mode_cards}</div></section>
<section><h2>实质性人类控制证明</h2><div class='grid'>{control_cards}</div></section>
<section><h2>平均普惠收益向量</h2><div class='grid'>{inclusion_cards}</div></section>
<section><h2>事件明细</h2><div class='scroll'><table><thead><tr><th>事件</th><th>领域</th><th>动作</th><th>影响</th><th>控制证明</th><th>运行模式</th><th>主要原因</th><th>普惠缺口</th><th>记录哈希</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
<section><h2>机器可读摘要</h2><pre class='card small'>{_esc(payload)}</pre></section>
</main><footer>DIKWP-CIVICLOOP² · Offline-first reference runtime · Synthetic demonstration only</footer></body></html>""", encoding="utf-8")
