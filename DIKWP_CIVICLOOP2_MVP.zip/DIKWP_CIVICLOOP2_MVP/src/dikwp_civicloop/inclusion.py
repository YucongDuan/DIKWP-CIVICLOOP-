from __future__ import annotations

from typing import List

from .models import DecisionEvent, InclusionBenefitRecord


class InclusionBenefitEvaluator:
    """Track benefit distribution without defining 'inclusion' as one universal score."""

    def evaluate(self, event: DecisionEvent) -> InclusionBenefitRecord:
        gaps: List[str] = []
        remedies: List[str] = []
        metrics = {
            "access": event.benefit_access,
            "capability": event.benefit_capability,
            "outcome": event.benefit_outcome,
            "voice_control": event.benefit_voice,
            "value_capture": event.benefit_value_capture,
        }
        labels = {
            "access": "可接入性",
            "capability": "实际使用能力",
            "outcome": "结果改善",
            "voice_control": "发声与控制权",
            "value_capture": "本地价值留存",
        }
        for key, value in metrics.items():
            if value < 0.45:
                gaps.append(f"{labels[key]}显著不足（{value:.2f}）")
            elif value < 0.65:
                gaps.append(f"{labels[key]}存在缺口（{value:.2f}）")

        if event.benefit_access < 0.65:
            remedies.append("提供低带宽、线下或人工协助入口，避免以智能终端作为唯一门槛。")
        if event.benefit_capability < 0.65:
            remedies.append("提供培训、辅助界面和面向老年人/残障人士的可达性支持。")
        if event.benefit_outcome < 0.65:
            remedies.append("以真实结果而非调用量、注册量或成本下降作为主要结算指标。")
        if event.benefit_voice < 0.65:
            remedies.append("让受影响群体参与规则、指标、申诉和版本变更。")
        if event.benefit_value_capture < 0.65:
            remedies.append("记录数据、经验与地方资源贡献，并设计本地价值回流和退出机制。")
        if event.externality_risk > 0.55:
            gaps.append(f"外部性风险偏高（{event.externality_risk:.2f}）")
            remedies.append("暂停扩大部署，补充第三方影响评估与损害修复准备金。")

        return InclusionBenefitRecord(
            event_id=event.event_id,
            affected_party=event.affected_party,
            access=event.benefit_access,
            capability=event.benefit_capability,
            outcome=event.benefit_outcome,
            voice_control=event.benefit_voice,
            value_capture=event.benefit_value_capture,
            gaps=gaps,
            required_remedies=remedies,
        )
