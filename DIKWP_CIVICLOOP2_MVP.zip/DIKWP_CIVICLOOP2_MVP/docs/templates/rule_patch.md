# Ethical Rule Patch — Template

- Patch ID / trigger event:
- Existing rule and observed failure:
- Affected parties and dissenting views:
- DIKWP transformation paths that support or oppose the patch:
- Proposed temporary change:
- Scope, jurisdiction and prohibited expansion:
- Effective date and automatic expiry:
- Review authority independent of the operator:
- Rollback test:
- Evidence that would renew, narrow or cancel the patch:
- Compatibility and migration impact:
