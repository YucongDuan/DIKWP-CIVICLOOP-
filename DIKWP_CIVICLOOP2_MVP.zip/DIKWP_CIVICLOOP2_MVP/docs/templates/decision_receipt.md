# Algorithmic Decision Receipt — Human-Readable Template

- Receipt ID:
- Date/time and jurisdiction:
- Responsible organization and named accountable role:
- AI/agent/model/tool versions:
- Proposed or executed action:
- Affected person or group:
- Legal/organizational authority:
- Purpose and competing purposes:
- Evidence used, provenance and known uncertainty:
- Human decision right and intervention window:
- Runtime mode:
- Alternatives considered:
- Expected benefit and foreseeable externalities:
- How to stop, reverse or recover:
- How to appeal; response deadline:
- Hash / previous record hash:
