# Appeal & Repair Ticket — Template

- Ticket ID / related receipt:
- Affected party and accessible contact channel:
- Rights or service at risk:
- Immediate restoration required:
- Severity and response deadline:
- Evidence disputed or missing:
- Human reviewer independent of the original automated decision:
- Temporary protection while review is pending:
- Final correction, compensation or service restoration:
- Rule/model/data changes proposed:
- Closure approval and audit hash:
