# Roadmap

## 0–30 days

- Freeze core schema names and publish an RFC repository.
- Add JSON Schema validation to CI.
- Open a public issue set for human-control counterexamples.
- Recruit one external security reviewer, one affected-party representative and one independent settlement editor.

## 31–100 days

- Run three shadow or bounded pilots.
- Publish at least one failed control proof and one repaired rights incident.
- Implement signed receipts and expiry-aware policy profiles.
- Release conformance vectors for a second independent implementation.

## 3–12 months

- Establish three field nodes in different sectors or regions.
- Add supply-chain attestations, model/tool version invalidation and recovery drills.
- Publish a bilingual Decision Receipt and Appeal API.
- Hold a public “Break Human Control” challenge.

## 12–24 months

- Version 1.0 only after independent implementation, real appeal testing, security audit and external settlement.
- Create a federation protocol in which evidence may travel but public authority must be re-established locally.
- Transfer at least one core maintainer and one settlement role outside the founding team.
