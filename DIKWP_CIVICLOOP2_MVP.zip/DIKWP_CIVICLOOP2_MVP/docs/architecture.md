# DIKWP-CIVICLOOP² Architecture

## Mission

DIKWP-CIVICLOOP² is an offline-first public-action runtime for AI systems that can affect people, organizations, public services, money, identity, employment, education, health care or physical equipment. It does not define safety, ethics, inclusion or human control as universal concepts. It compiles each concrete action into auditable relations among actors, authority, evidence, purpose, affected parties, reversibility, appeal and recovery.

## Runtime graph

```text
Actor / Agent Passport
        ↕
Definition-free Intent Field ↔ DIKWP×DIKWP Mesh (25 ordered transformations)
        ↕
Decision Event → Meaningful Human Control Proof → Decision Rights Graph
        ↘                 ↓                         ↙
          Inclusion & Benefit Ledger      Action Fence / Runtime Mode
                    ↘                     ↙
               Algorithmic Decision Receipt
                    ↙          ↓          ↘
        Appeal & Repair   Ethical Rule Patch   Hash Ledger
```

The graph is deliberately non-hierarchical. Any new Data, Information, Knowledge, Wisdom or Purpose resource may revise any other resource. Purpose is not a privileged root and may be split, suspended or rejected.

## Core objects

- **ActorPassport**: identity, accountable organization, operator, owner, authority basis, capability and deployment boundary.
- **IntentField**: competing and revisable intentions, protected continuities, prohibited consequences and unresolved conflicts.
- **DecisionEvent**: a concrete proposed or executed action, not a general model score.
- **HumanControlProof**: nine action-specific tests for awareness, intervention, authority, capacity, independence, reversibility, traceability, non-displacement and appeal.
- **DecisionRightsResult**: who may observe, advise, propose, execute, require a human, hold, block or freeze/recover.
- **DecisionReceipt**: public-facing explanation of what happened, why, with whose authority, under what uncertainty and how to appeal.
- **AppealRepairTicket**: restoration-first process for affected parties.
- **EthicalRulePatch**: expiring, reviewable, reversible change triggered by evidence, incident or affected-party objection.
- **InclusionBenefitRecord**: access, capability, outcome, voice and local value capture kept as a vector rather than compressed into one score.
- **HashLedger**: append-only provenance and settlement trail.

## Runtime modes

`OBSERVE`, `ADVISE`, `PROPOSE`, `EXECUTE_REVERSIBLE`, `REQUIRE_HUMAN`, `HOLD`, `BLOCK`, `FREEZE_RECOVER`.

No average score may override a hard right or an impossible human-control condition.

## Deployment boundary

The reference implementation is a research simulator. It must not be connected to real benefits, clinical care, hiring, credit, identity, public-resource allocation or industrial control without lawful authorization, domain validation, affected-party participation, recovery exercises, security review and independent settlement.
