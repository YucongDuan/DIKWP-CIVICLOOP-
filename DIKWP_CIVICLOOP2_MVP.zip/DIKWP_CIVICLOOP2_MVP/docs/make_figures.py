from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'docs' / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
summary = json.loads((ROOT / 'outputs' / 'summary.json').read_text(encoding='utf-8'))
assessments = json.loads((ROOT / 'outputs' / 'assessments.json').read_text(encoding='utf-8'))

font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_bold_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
font_prop = font_manager.FontProperties(fname=font_path)
font_bold = font_manager.FontProperties(fname=font_bold_path)
plt.rcParams['font.family'] = font_prop.get_name()
plt.rcParams['axes.unicode_minus'] = False


def save(fig, name):
    fig.tight_layout()
    fig.savefig(FIG / name, dpi=210, bbox_inches='tight')
    plt.close(fig)


# 1. Four questions -> four evidence packages -> action loop
fig, ax = plt.subplots(figsize=(11, 6.3))
ax.axis('off')
questions = [
    ('机器开始思考', '角色、身份与边界证据包'),
    ('算法参与决策', '实质性人类控制证明'),
    ('技术挑战伦理', '可到期、可回滚的规则补丁'),
    ('鸿沟不断拉大', '普惠收益与权力分配账本'),
]
xs = [0.13, 0.38, 0.63, 0.88]
for x, (q, p) in zip(xs, questions):
    ax.text(x, .76, q, ha='center', va='center', fontproperties=font_bold, fontsize=13,
            bbox=dict(boxstyle='round,pad=.45'))
    ax.annotate('', xy=(x, .56), xytext=(x, .69), arrowprops=dict(arrowstyle='->', lw=1.6))
    ax.text(x, .48, p, ha='center', va='center', fontproperties=font_prop, fontsize=11,
            bbox=dict(boxstyle='round,pad=.5'))
    ax.annotate('', xy=(.5, .23), xytext=(x, .39), arrowprops=dict(arrowstyle='->', lw=1.2, connectionstyle='arc3,rad=.05'))
ax.text(.5, .16, '行动 → 结果 → 申诉/修复 → 规则更新 → 下一次行动', ha='center', va='center',
        fontproperties=font_bold, fontsize=14, bbox=dict(boxstyle='round,pad=.6'))
ax.text(.5, .94, 'DIKWP-CIVICLOOP²：将“四问”编译为每次行动可检验的证据，而非抽象口号',
        ha='center', va='center', fontproperties=font_bold, fontsize=15)
save(fig, 'fig1_four_questions_loop.png')

# 2. Architecture
fig, ax = plt.subplots(figsize=(11, 7.2))
ax.axis('off')
rows = [
    ('现实接口', ['公共服务', '工业设备', '企业软件', '个人智能体', '全球南方节点']),
    ('行动运行时', ['决策权图', '控制证明', '动作围栏', '决策回执', '冻结恢复']),
    ('权利与收益', ['申诉修复', '非AI替代', '数据主权', '普惠收益账本', '外部性账本']),
    ('语义与证据', ['DIKWP×DIKWP', '意图场', '来源/不确定性', '反证', '规则补丁']),
    ('联邦治理', ['中国政策配置', '行业配置', '地方配置', '独立结算', '版本/日落']),
]
y = .86
for title, items in rows:
    ax.add_patch(Rectangle((.05, y-.085), .9, .13, fill=False, linewidth=1.2))
    ax.text(.07, y, title, va='center', fontproperties=font_bold, fontsize=12)
    start = .22
    width = .72 / len(items)
    for i, item in enumerate(items):
        ax.text(start + width*(i+.5), y, item, ha='center', va='center', fontproperties=font_prop, fontsize=9.3,
                bbox=dict(boxstyle='round,pad=.32'))
    if y > .25:
        ax.annotate('', xy=(.5, y-.115), xytext=(.5, y-.08), arrowprops=dict(arrowstyle='<->'))
    y -= .17
ax.text(.5, .97, 'CIVICLOOP² 横向公共运行时架构', ha='center', va='center', fontproperties=font_bold, fontsize=16)
save(fig, 'fig2_architecture.png')

# 3. DIKWP network complete directed
fig, ax = plt.subplots(figsize=(7.5, 7.0))
ax.axis('off')
labels = ['D', 'I', 'K', 'W', 'P']
angles = [math.radians(90 - i*72) for i in range(5)]
pos = {lab:(.5+.34*math.cos(a), .5+.34*math.sin(a)) for lab,a in zip(labels,angles)}
for s in labels:
    for t in labels:
        if s == t:
            x,y=pos[s]
            patch = FancyArrowPatch((x+.03,y+.02),(x+.02,y+.03),connectionstyle='arc3,rad=1.7',arrowstyle='-|>',mutation_scale=8,linewidth=.55)
        else:
            patch = FancyArrowPatch(pos[s],pos[t],connectionstyle='arc3,rad=.08',arrowstyle='-|>',mutation_scale=7,linewidth=.45)
        ax.add_patch(patch)
for lab,(x,y) in pos.items():
    ax.text(x,y,lab,ha='center',va='center',fontproperties=font_bold,fontsize=20,bbox=dict(boxstyle='circle,pad=.55'))
ax.text(.5,.96,'完整25类 DIKWP×DIKWP 变换：Purpose 不是最高控制器',ha='center',fontproperties=font_bold,fontsize=14)
ax.text(.5,.04,'每条变换同时带观察者、语境、时间、尺度、模态、来源和意图场索引',ha='center',fontproperties=font_prop,fontsize=10)
save(fig, 'fig3_dikwp_mesh.png')

# 4. Action modes
fig, ax = plt.subplots(figsize=(10.5, 5.8))
ax.axis('off')
modes = ['OBSERVE','ADVISE','PROPOSE','EXECUTE_REVERSIBLE','REQUIRE_HUMAN','HOLD','BLOCK','FREEZE_RECOVER']
cn = ['观察','建议','提出方案','可逆执行','必须人工决定','等待补证','阻断','冻结并恢复']
for i,(m,c) in enumerate(zip(modes,cn)):
    x=.08+i*.115
    ax.text(x,.58,m+'\n'+c,ha='center',va='center',fontproperties=font_prop,fontsize=8.7,bbox=dict(boxstyle='round,pad=.4'))
    if i < len(modes)-1:
        ax.annotate('',xy=(x+.075,.58),xytext=(x+.045,.58),arrowprops=dict(arrowstyle='->',lw=1))
ax.text(.5,.86,'动作状态不是能力等级，而是每次具体行动的授权与恢复状态',ha='center',fontproperties=font_bold,fontsize=14)
ax.text(.5,.25,'状态可以双向变化：新证据、事故、申诉或规则补丁可使动作升级、降级、暂停或回滚',ha='center',fontproperties=font_prop,fontsize=11)
save(fig, 'fig4_action_modes.png')

# 5. Human control test pass rates from synthetic data
names = ['awareness','intervention_window','actual_authority','review_capacity','review_independence','reversibility_and_recovery','traceability','non_ai_alternative','appeal_and_repair']
counts = {n:[0,0] for n in names}
for a in assessments:
    for t in a['control_proof']['tests']:
        if t['name'] in counts and t['passed'] is not None:
            counts[t['name']][1]+=1
            if t['passed']: counts[t['name']][0]+=1
rates=[counts[n][0]/counts[n][1] if counts[n][1] else 0 for n in names]
fig, ax = plt.subplots(figsize=(10.5,6.2))
ax.barh(range(len(names)),rates)
ax.set_yticks(range(len(names)),labels=names,fontproperties=font_prop)
ax.set_xlim(0,1)
ax.set_xlabel('合成事件通过比例',fontproperties=font_prop)
ax.set_title('实质性人类控制证明：九项独立测试',fontproperties=font_bold,fontsize=14)
for i,v in enumerate(rates): ax.text(v+.01,i,f'{v:.0%}',va='center',fontproperties=font_prop,fontsize=9)
save(fig, 'fig5_control_tests.png')

# 6. Inclusion vector
inc=summary['average_inclusion']
fig, ax = plt.subplots(figsize=(8.5,5.4))
keys=['access','capability','outcome','voice','value_capture']
vals=[inc[k] for k in keys]
ax.bar(keys,vals)
ax.set_ylim(0,1)
ax.set_ylabel('合成平均值',fontproperties=font_prop)
ax.set_title('普惠不是“是否接入”的单一指标：五维收益向量',fontproperties=font_bold,fontsize=14)
for i,v in enumerate(vals): ax.text(i,v+.025,f'{v:.2f}',ha='center',fontproperties=font_prop)
save(fig, 'fig6_inclusion_vector.png')

# 7. GitHub integration map
fig, ax = plt.subplots(figsize=(11,7.0))
ax.axis('off')
center=(.5,.5)
ax.text(*center,'CIVICLOOP²\n公共行动运行时',ha='center',va='center',fontproperties=font_bold,fontsize=14,bbox=dict(boxstyle='round,pad=.8'))
repos=[
    ('MESH² / INTENTFIELD²','语义网与意图场'),('PACT / P-Space','目的与权限'),('ProofLedger / CREDENCE²','证据与复现'),
    ('MANDATE² / PRAXIS²','授权与行动'),('Civicode','制度权力可争议'),('ARK / GlobalDividend','兜底与普惠'),
    ('AgentTrace','行为链'),('AION / SINOTRACE²','预测与触发')]
for i,(name,role) in enumerate(repos):
    a=math.radians(90-i*45)
    x=.5+.38*math.cos(a); y=.5+.36*math.sin(a)
    ax.text(x,y,name+'\n'+role,ha='center',va='center',fontproperties=font_prop,fontsize=9.5,bbox=dict(boxstyle='round,pad=.45'))
    ax.add_patch(FancyArrowPatch((x,y),center,arrowstyle='<->',mutation_scale=10,linewidth=.8))
ax.text(.5,.96,'不是再建一个孤立仓库，而是把现有仓库编译为同一行动闭环',ha='center',fontproperties=font_bold,fontsize=14)
save(fig, 'fig7_github_integration.png')

# 8. 100-day roadmap
fig, ax = plt.subplots(figsize=(11,4.8))
ax.set_xlim(0,100); ax.set_ylim(0,6); ax.set_yticks([]); ax.set_xlabel('天',fontproperties=font_prop)
ax.set_title('100天开源交付路线',fontproperties=font_bold,fontsize=14)
phases=[(0,15,'冻结接口与仓库地图'),(15,30,'Schema / Profiles v0.1'),(30,50,'三个影子试点'),(50,70,'外部复现与红队'),(70,90,'申诉/恢复演练'),(90,100,'v0.2与维护权移交')]
for idx,(s,e,label) in enumerate(phases):
    y=5-idx*.8
    ax.barh(y,e-s,left=s,height=.5)
    ax.text((s+e)/2,y,label,ha='center',va='center',fontproperties=font_prop,fontsize=9)
ax.grid(axis='x',alpha=.25)
save(fig, 'fig8_roadmap.png')

# 9. Runtime modes
fig, ax = plt.subplots(figsize=(9.6,5.6))
items=sorted(summary['runtime_modes'].items(),key=lambda x:x[1],reverse=True)
ax.bar([k for k,v in items],[v for k,v in items])
ax.set_ylabel('事件数',fontproperties=font_prop)
ax.set_title('180个合成事件的动作模式分布',fontproperties=font_bold,fontsize=14)
ax.tick_params(axis='x',rotation=28)
for i,(k,v) in enumerate(items): ax.text(i,v+1,str(v),ha='center',fontproperties=font_prop,fontsize=9)
save(fig, 'fig9_runtime_modes.png')

# 10. Control state
fig, ax = plt.subplots(figsize=(8.5,5.2))
items=sorted(summary['control_states'].items(),key=lambda x:x[1],reverse=True)
ax.bar([k for k,v in items],[v for k,v in items])
ax.set_ylabel('事件数',fontproperties=font_prop)
ax.set_title('实质性人类控制证明状态（合成演示）',fontproperties=font_bold,fontsize=14)
for i,(k,v) in enumerate(items): ax.text(i,v+1,str(v),ha='center',fontproperties=font_prop)
save(fig, 'fig10_control_states.png')

print('generated',len(list(FIG.glob('*.png'))),'figures')
