# 90-Day Pilot Plan

## Gate 0 — non-negotiable conditions

The pilot remains in simulation or shadow mode unless it has a named accountable organization, a legal basis, affected-party representation, an independent appeal route, a recovery plan and an explicit expiry date. No model is permitted to expand its own permissions.

## Pilot A — employment and social-security shadow audit

**Mode:** `SHADOW / REQUIRE_HUMAN`

- Replay historical or synthetic cases without changing real benefits.
- Generate Decision Receipts and compare them with human decisions.
- Test whether affected people can understand the basis, contest evidence and reach a human reviewer.
- Success is measured by error discovery, restoration readiness and appeal usability, not denial-rate reduction.

## Pilot B — bounded industrial agent

**Mode:** `EXECUTE_REVERSIBLE` inside a physical sandbox

- Limit equipment, speed, workspace, tools and operating time.
- Prove operator awareness, intervention time, physical interlock and state recovery.
- Run fault injection, sensor-loss and network-loss exercises.
- Any change to model, toolchain, hardware or operating range invalidates the prior Human Control Proof.

## Pilot C — low-bandwidth public-service assistant

**Mode:** `ADVISE / PROPOSE`

- Keep telephone, counter and offline alternatives.
- Test dialects, older users, low literacy, disability access and intermittent connectivity.
- Record all five inclusion dimensions: access, capability, outcome, voice and local value capture.
- Do not close an existing channel merely because digital usage increases.

## Independent settlement

At day 90, a non-operator team issues one of: continue, modify, narrow, repeat, suspend or stop. The report must publish failures, unresolved residuals and affected-party objections, not only aggregate performance.
