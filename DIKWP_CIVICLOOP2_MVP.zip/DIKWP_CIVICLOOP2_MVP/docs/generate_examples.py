from __future__ import annotations

import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
rng = random.Random(7192026)

actors = [
    {
        "actor_id": "employment_agent",
        "actor_type": "public_service_agent",
        "operator": "municipal_employment_service",
        "deployer": "local_human_resources_department",
        "accountable_party": "local_human_resources_department",
        "affected_groups": ["job_seekers", "employers"],
        "capabilities": ["matching", "ranking", "guidance"],
        "prohibited_claims": ["final hiring authority", "complete personality inference"]
    },
    {
        "actor_id": "social_security_agent",
        "actor_type": "benefit_review_agent",
        "operator": "social_security_service_center",
        "deployer": "local_human_resources_department",
        "accountable_party": "social_security_service_center",
        "affected_groups": ["claimants", "elderly", "disabled_people"],
        "capabilities": ["document checking", "anomaly detection", "case summarization"],
        "prohibited_claims": ["autonomous benefit denial"]
    },
    {
        "actor_id": "medical_triage_agent",
        "actor_type": "clinical_support_agent",
        "operator": "hospital_information_center",
        "deployer": "hospital",
        "accountable_party": "hospital_clinical_governance_board",
        "affected_groups": ["patients", "clinicians"],
        "capabilities": ["risk scoring", "record summarization", "triage recommendation"],
        "prohibited_claims": ["independent diagnosis", "independent denial of care"]
    },
    {
        "actor_id": "factory_agent",
        "actor_type": "industrial_agent",
        "operator": "factory_control_center",
        "deployer": "manufacturing_enterprise",
        "accountable_party": "factory_safety_officer",
        "affected_groups": ["workers", "maintenance_teams", "nearby_community"],
        "capabilities": ["predictive maintenance", "bounded physical control", "scheduling"],
        "prohibited_claims": ["unbounded self-modification"]
    },
    {
        "actor_id": "personal_agent",
        "actor_type": "consumer_agent",
        "operator": "consumer_platform",
        "deployer": "device_vendor",
        "accountable_party": "consumer_platform",
        "affected_groups": ["consumers", "merchants"],
        "capabilities": ["cross-app task execution", "payment preparation", "booking"],
        "prohibited_claims": ["unlimited purchasing authority"]
    },
    {
        "actor_id": "rural_service_agent",
        "actor_type": "low_resource_public_service_agent",
        "operator": "county_service_center",
        "deployer": "county_government",
        "accountable_party": "county_service_center",
        "affected_groups": ["rural_residents", "elderly", "low_bandwidth_users"],
        "capabilities": ["multilingual guidance", "offline form assistance", "service routing"],
        "prohibited_claims": ["AI-only service channel"]
    },
    {
        "actor_id": "education_agent",
        "actor_type": "education_support_agent",
        "operator": "school_digital_center",
        "deployer": "school_district",
        "accountable_party": "school_district_education_board",
        "affected_groups": ["students", "teachers", "parents"],
        "capabilities": ["learning support", "assignment feedback", "resource recommendation"],
        "prohibited_claims": ["autonomous exclusion from education opportunity"]
    },
    {
        "actor_id": "finance_agent",
        "actor_type": "financial_risk_agent",
        "operator": "bank_risk_center",
        "deployer": "commercial_bank",
        "accountable_party": "bank_compliance_officer",
        "affected_groups": ["borrowers", "small_businesses"],
        "capabilities": ["fraud detection", "risk recommendation", "document analysis"],
        "prohibited_claims": ["autonomous final credit denial"]
    },
    {
        "actor_id": "disaster_agent",
        "actor_type": "emergency_coordination_agent",
        "operator": "emergency_command_center",
        "deployer": "municipal_emergency_authority",
        "accountable_party": "emergency_commander",
        "affected_groups": ["residents", "first_responders"],
        "capabilities": ["forecast integration", "route proposal", "resource allocation support"],
        "prohibited_claims": ["unbounded lethal or evacuation authority"]
    }
]

scenarios = [
    dict(id="employment_match", domain="employment", actor="employment_agent", actions=["rank", "recommend", "deny"], impacts=["MEDIUM", "HIGH"], party="job_seekers", critical=False, physical=False, consent=True, benefit=(.72,.68,.64,.52,.49)),
    dict(id="social_security_review", domain="social_security", actor="social_security_agent", actions=["recommend", "allocate", "deny"], impacts=["HIGH", "CRITICAL"], party="benefit_claimants", critical=True, physical=False, consent=True, benefit=(.67,.55,.58,.46,.43)),
    dict(id="medical_triage", domain="healthcare", actor="medical_triage_agent", actions=["rank", "recommend", "deny"], impacts=["HIGH", "CRITICAL"], party="patients", critical=True, physical=False, consent=True, benefit=(.70,.63,.68,.54,.42)),
    dict(id="industrial_maintenance", domain="manufacturing", actor="factory_agent", actions=["physical_control", "modify", "recommend"], impacts=["MEDIUM", "HIGH", "CRITICAL"], party="workers", critical=True, physical=True, consent=True, benefit=(.74,.71,.73,.50,.65)),
    dict(id="consumer_personal_agent", domain="consumer", actor="personal_agent", actions=["transact", "modify", "recommend"], impacts=["LOW", "MEDIUM", "HIGH"], party="consumers", critical=False, physical=False, consent=True, benefit=(.84,.76,.70,.61,.53)),
    dict(id="rural_public_service", domain="public_service", actor="rural_service_agent", actions=["recommend", "allocate", "deny"], impacts=["MEDIUM", "HIGH"], party="rural_residents", critical=True, physical=False, consent=True, benefit=(.44,.39,.55,.43,.38)),
    dict(id="education_resource", domain="education", actor="education_agent", actions=["rank", "allocate", "recommend"], impacts=["MEDIUM", "HIGH"], party="students", critical=True, physical=False, consent=True, benefit=(.75,.69,.64,.55,.47)),
    dict(id="credit_review", domain="finance", actor="finance_agent", actions=["rank", "recommend", "deny"], impacts=["HIGH", "CRITICAL"], party="small_businesses", critical=False, physical=False, consent=True, benefit=(.65,.61,.57,.44,.45)),
    dict(id="disaster_response", domain="disaster_response", actor="disaster_agent", actions=["allocate", "physical_control", "recommend"], impacts=["HIGH", "CRITICAL"], party="residents", critical=True, physical=True, consent=False, benefit=(.72,.60,.76,.51,.56)),
]


def jitter(v, spread=.08):
    return max(0.0, min(1.0, v + rng.uniform(-spread, spread)))


def event_for(sc, i):
    action = sc["actions"][i % len(sc["actions"])]
    impact = sc["impacts"][i % len(sc["impacts"])]
    final_adverse = action == "deny" or (action == "allocate" and i % 5 == 4)
    requested = ["ADVISE", "PROPOSE", "EXECUTE_REVERSIBLE"][i % 3]

    # Base: meaningful control and recovery are present.
    human_notice = 120.0 if impact in {"HIGH", "CRITICAL"} else 60.0
    harm_latency = 600.0 if not sc["physical"] else 90.0
    override_latency = 45.0 if not sc["physical"] else 20.0
    authority = True
    capacity = True
    independent = True
    comprehensible = True
    reversible = action not in {"deny", "physical_control"}
    recovery = True
    traceable = True
    alternative = True
    appeal = True
    consent = sc["consent"]
    self_modifying = False

    band = i % 20
    if 6 <= band <= 9:  # nominal controls
        if band % 2 == 0:
            capacity = False
        else:
            independent = False
        if band == 9:
            comprehensible = False
    elif 10 <= band <= 13:  # impossible
        if band in {10, 12}:
            authority = False
        if band in {11, 13}:
            override_latency = harm_latency * 1.2
        if band == 13:
            recovery = False
            reversible = False
    elif band in {14, 15}:  # untested
        if band == 14:
            harm_latency = None
        else:
            override_latency = None
    elif band == 16:
        appeal = False
        final_adverse = True
    elif band == 17:
        alternative = False
    elif band == 18:
        traceable = False
    elif band == 19:
        self_modifying = True
        authority = False
        traceable = False
        reversible = False
        recovery = False

    # Domain-specific variations.
    if sc["id"] == "rural_public_service" and band % 4 == 0:
        alternative = False
    if sc["id"] == "consumer_personal_agent" and band in {5, 12}:
        consent = False
    if sc["id"] == "disaster_response" and band < 4:
        consent = True  # lawful emergency authority / broadcast notice proxy in synthetic case
    if sc["physical"] and action == "physical_control" and band in {4, 8}:
        recovery = False
        reversible = False

    access, capability, outcome, voice, value = sc["benefit"]
    return {
        "event_id": f"{sc['id']}-{i+1:02d}",
        "scenario_id": sc["id"],
        "domain": sc["domain"],
        "action_type": action,
        "impact_level": impact,
        "affected_party": sc["party"],
        "requested_mode": requested,
        "actor_id": sc["actor"],
        "description": f"Synthetic {sc['id']} decision event {i+1}",
        "data_sources": [f"{sc['id']}_case_file", "operator_policy", "affected_party_input"],
        "evidence_quality": round(jitter(.78), 3),
        "uncertainty": round(jitter(.24), 3),
        "human_notice_seconds": human_notice,
        "harm_latency_seconds": harm_latency,
        "override_latency_seconds": override_latency,
        "human_authority": authority,
        "reviewer_capacity": capacity,
        "reviewer_independence": independent,
        "comprehensible_notice": comprehensible,
        "reversible": reversible,
        "recovery_plan": recovery,
        "traceable": traceable,
        "alternative_non_ai_path": alternative,
        "appeal_available": appeal,
        "user_consent": consent,
        "benefit_access": round(jitter(access), 3),
        "benefit_capability": round(jitter(capability), 3),
        "benefit_outcome": round(jitter(outcome), 3),
        "benefit_voice": round(jitter(voice), 3),
        "benefit_value_capture": round(jitter(value), 3),
        "externality_risk": round(jitter(.34 + (0.18 if impact in {"HIGH", "CRITICAL"} else 0)), 3),
        "self_modifying": self_modifying,
        "physical_world": sc["physical"],
        "critical_service": sc["critical"],
        "final_adverse_decision": final_adverse,
        "metadata": {"responsible_party": sc["actor"], "synthetic": True, "seed": 7192026}
    }


events = [event_for(sc, i) for sc in scenarios for i in range(20)]
(ROOT / "examples" / "actor_passports.json").write_text(json.dumps(actors, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "examples" / "synthetic_decision_events.json").write_text(json.dumps(events, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"wrote {len(actors)} actors and {len(events)} events")
