# China Policy Mapping — Research Snapshot 2026-07-19

This document is a research mapping, not an official interpretation or compliance opinion.

## Four public questions → runtime evidence

| Public question | Operational relation tested by CIVICLOOP² | Primary runtime output |
|---|---|---|
| When machines increasingly reason and act, how do humans coexist with them? | Who or what is acting; whose goals are represented; whether identity, capability and deployment boundary are declared | Actor Passport + Intent Field |
| When algorithms participate in decisions, how is safety protected? | Who holds the legal and practical decision right; whether the human can understand, intervene, stop and restore | Human Control Proof + Decision Rights Graph |
| When technology challenges ethics, how can governance keep pace? | How an incident changes a rule without converting one temporary reaction into permanent, unreviewable power | Ethical Rule Patch |
| When gaps widen, how is inclusion achieved? | Whether people can access, use, benefit, contest and locally retain value | Inclusion & Benefit Ledger |

## Policy profiles in the MVP

- `cn_agent_2026`: identity, capability declaration, permissions, final decision rights, behavior fences, traceability, intervention and recovery.
- `cn_ai_plus_2027`: broad adoption, public benefit, safe and controllable deployment, industrial and social application.
- `cn_manufacturing_2026`: industrial agents, physical action boundaries, equipment state, operator takeover and recovery.
- `cn_public_service`: no final automated denial in basic rights or essential services; understandable receipt, human review and restoration.
- `cn_global_south`: language, low-bandwidth access, local maintenance, data sovereignty, local value capture and exit.

## Research sources

- 2026 World Artificial Intelligence Conference keynote speech.
- 2026 policy guidance on standardized application and innovative development of intelligent agents.
- State Council “AI+” action guidance.
- “AI+ Manufacturing” implementation guidance.
- “AI+ Human Resources and Social Security” implementation guidance.

Every real deployment must re-map current law, local authority, sector standards and affected-party needs. Evidence can be reused; public authority cannot be inherited from this profile.
