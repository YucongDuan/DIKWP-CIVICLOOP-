from __future__ import annotations

import json
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path('/mnt/data/DIKWP_CIVICLOOP2_MVP')
OUT = Path('/mnt/data/DIKWP_CIVICLOOP2_China_AI_Four_Questions_Control_Plane_Report_CN.docx')
FIG = ROOT / 'docs' / 'figures'
summary = json.loads((ROOT / 'outputs' / 'summary.json').read_text(encoding='utf-8'))
assessments = json.loads((ROOT / 'outputs' / 'assessments.json').read_text(encoding='utf-8'))

NAVY='173F4F'; TEAL='1D6575'; LIGHT='E8F1F3'; PALE='F5F8F9'; DARK='1E2D34'; GREY='5D6B75'; LINE='D8E0E6'; RED='8B3D45'; GREEN='2F6F5E'; GOLD='9A742B'


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr(); shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    tcPr = cell._tc.get_or_add_tcPr(); tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for name, value in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node = tcMar.find(qn(f'w:{name}'))
        if node is None:
            node = OxmlElement(f'w:{name}'); tcMar.append(node)
        node.set(qn('w:w'), str(value)); node.set(qn('w:type'), 'dxa')


def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr(); node = OxmlElement('w:tblHeader'); node.set(qn('w:val'),'true'); trPr.append(node)


def set_row_cant_split(row):
    trPr = row._tr.get_or_add_trPr()
    if trPr.find(qn('w:cantSplit')) is None:
        node=OxmlElement('w:cantSplit'); node.set(qn('w:val'),'true'); trPr.append(node)


def set_run_font(run, east='Noto Serif CJK SC', latin='Aptos', size=None, bold=None, color=None, italic=None):
    run.font.name = latin
    rpr = run._element.get_or_add_rPr()
    if rpr.rFonts is None:
        rfonts = OxmlElement('w:rFonts'); rpr.insert(0, rfonts)
    rpr.rFonts.set(qn('w:eastAsia'), east)
    if size: run.font.size = Pt(size)
    if bold is not None: run.bold = bold
    if italic is not None: run.italic = italic
    if color: run.font.color.rgb = RGBColor.from_string(color)


def set_para_spacing(p, before=0, after=6, line=1.4):
    pf=p.paragraph_format; pf.space_before=Pt(before); pf.space_after=Pt(after); pf.line_spacing=line


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    begin=OxmlElement('w:fldChar'); begin.set(qn('w:fldCharType'),'begin')
    text=OxmlElement('w:instrText'); text.set(qn('xml:space'),'preserve'); text.text=' PAGE '
    end=OxmlElement('w:fldChar'); end.set(qn('w:fldCharType'),'end')
    run._r.extend([begin,text,end]); set_run_font(run,east='Noto Sans CJK SC',size=9,color=GREY)


def add_hyperlink(paragraph, text, url, color=TEAL):
    part=paragraph.part
    rid=part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
    h=OxmlElement('w:hyperlink'); h.set(qn('r:id'),rid)
    r=OxmlElement('w:r'); rPr=OxmlElement('w:rPr')
    c=OxmlElement('w:color'); c.set(qn('w:val'),color); rPr.append(c)
    u=OxmlElement('w:u'); u.set(qn('w:val'),'single'); rPr.append(u)
    fonts=OxmlElement('w:rFonts'); fonts.set(qn('w:eastAsia'),'Noto Sans CJK SC'); fonts.set(qn('w:ascii'),'Aptos'); rPr.append(fonts)
    r.append(rPr); t=OxmlElement('w:t'); t.text=text; r.append(t); h.append(r); paragraph._p.append(h)


def add_image_alt(shape, title, description):
    shape._inline.docPr.set('title', title); shape._inline.docPr.set('descr', description)


def add_body(doc, text, *, indent=True, after=7, bold_prefix=None):
    p=doc.add_paragraph(style='Body Text')
    if indent: p.paragraph_format.first_line_indent=Cm(0.74)
    if bold_prefix and text.startswith(bold_prefix):
        r=p.add_run(bold_prefix); set_run_font(r,bold=True)
        r=p.add_run(text[len(bold_prefix):]); set_run_font(r)
    else:
        r=p.add_run(text); set_run_font(r)
    set_para_spacing(p,after=after,line=1.43)
    return p


def add_bullet(doc, text, level=0, color=None):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    r=p.add_run(text); set_run_font(r,color=color); set_para_spacing(p,after=3,line=1.3); return p


def add_number(doc, text, level=0):
    p=doc.add_paragraph(style='List Number' if level==0 else 'List Number 2')
    r=p.add_run(text); set_run_font(r); set_para_spacing(p,after=3,line=1.3); return p


def heading(doc, text, level=1):
    p=doc.add_heading(text, level=level); set_para_spacing(p,before=8 if level==1 else 4,after=6,line=1.15); return p


def add_callout(doc, title, body, fill=LIGHT, accent=TEAL):
    tbl=doc.add_table(rows=1,cols=1); tbl.alignment=WD_TABLE_ALIGNMENT.CENTER; tbl.autofit=False; tbl.columns[0].width=Cm(16.2)
    row=tbl.rows[0]; set_repeat_table_header(row); set_row_cant_split(row)
    cell=tbl.cell(0,0); set_cell_shading(cell,fill); set_cell_margins(cell,150,220,150,220)
    p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(3)
    r=p.add_run(title); set_run_font(r,east='Noto Sans CJK SC',bold=True,size=12,color=accent)
    p2=cell.add_paragraph(); p2.paragraph_format.line_spacing=1.35; p2.paragraph_format.space_after=Pt(0)
    r=p2.add_run(body); set_run_font(r,size=10.4)
    spacer=doc.add_paragraph(); spacer.paragraph_format.space_after=Pt(0)
    return tbl


def add_equation(doc, text, note=None):
    tbl=doc.add_table(rows=1,cols=1); tbl.alignment=WD_TABLE_ALIGNMENT.CENTER; tbl.autofit=False; tbl.columns[0].width=Cm(15.6)
    set_repeat_table_header(tbl.rows[0]); set_row_cant_split(tbl.rows[0]); c=tbl.cell(0,0); set_cell_shading(c,'F1F4F5'); set_cell_margins(c,130,180,130,180)
    p=c.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(text); set_run_font(r,east='Noto Sans Mono CJK SC',latin='Consolas',size=9.6,bold=True,color=DARK)
    if note:
        p2=c.add_paragraph(); p2.alignment=WD_ALIGN_PARAGRAPH.CENTER; p2.paragraph_format.space_after=Pt(0)
        r=p2.add_run(note); set_run_font(r,size=8.7,color=GREY)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


def add_table(doc, headers, rows, widths=None, font_size=8.5, header_fill=NAVY):
    tbl=doc.add_table(rows=1,cols=len(headers)); tbl.style='Table Grid'; tbl.alignment=WD_TABLE_ALIGNMENT.CENTER
    hrow=tbl.rows[0]; set_repeat_table_header(hrow); set_row_cant_split(hrow)
    for i,h in enumerate(headers):
        c=hrow.cells[i]; c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; set_cell_shading(c,header_fill); set_cell_margins(c)
        p=c.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(0)
        r=p.add_run(str(h)); set_run_font(r,east='Noto Sans CJK SC',bold=True,size=font_size,color='FFFFFF')
    for ridx,row in enumerate(rows):
        rr=tbl.add_row(); set_row_cant_split(rr)
        if ridx % 2 == 1:
            for c in rr.cells: set_cell_shading(c,'F7F9FA')
        for i,val in enumerate(row):
            c=rr.cells[i]; c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; set_cell_margins(c)
            p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.15
            r=p.add_run(str(val)); set_run_font(r,size=font_size)
    if widths:
        for row in tbl.rows:
            for i,w in enumerate(widths): row.cells[i].width=Cm(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return tbl


def add_figure(doc, filename, caption, alt, width=15.8):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    shape=p.add_run().add_picture(str(FIG/filename),width=Cm(width)); add_image_alt(shape,caption,alt)
    cp=doc.add_paragraph(); cp.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(cp,after=8,line=1.1)
    r=cp.add_run(caption); set_run_font(r,east='Noto Sans CJK SC',size=9.1,color=GREY)


def page_break(doc): doc.add_page_break()


def add_source(doc, index, title, descriptor, url=None):
    p=doc.add_paragraph(style='Body Text'); p.paragraph_format.left_indent=Cm(0.5); p.paragraph_format.first_line_indent=Cm(-0.5); set_para_spacing(p,after=3,line=1.25)
    r=p.add_run(f'[{index}] {title}. '); set_run_font(r,bold=True,size=9.2)
    r=p.add_run(descriptor); set_run_font(r,size=9.2)
    if url:
        p.add_run(' '); add_hyperlink(p,'访问来源',url)


def add_paragraphs(doc, paragraphs):
    for t in paragraphs: add_body(doc,t)


def add_code_block(doc, text):
    tbl=doc.add_table(rows=1,cols=1); tbl.alignment=WD_TABLE_ALIGNMENT.CENTER; tbl.autofit=False; tbl.columns[0].width=Cm(16.1)
    set_repeat_table_header(tbl.rows[0]); set_row_cant_split(tbl.rows[0]); c=tbl.cell(0,0); set_cell_shading(c,'F2F4F5'); set_cell_margins(c,130,150,130,150)
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.1
    r=p.add_run(text); set_run_font(r,east='Noto Sans Mono CJK SC',latin='Consolas',size=8.3,color=DARK)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


doc=Document()
sec=doc.sections[0]
sec.top_margin=Cm(2.05); sec.bottom_margin=Cm(1.85); sec.left_margin=Cm(2.2); sec.right_margin=Cm(2.0); sec.header_distance=Cm(0.8); sec.footer_distance=Cm(0.8)

props=doc.core_properties
props.title='DIKWP-CIVICLOOP²：中国AI四问公共运行时与实质性人类控制系统'
props.subject='面向中国未来AI发展的实质性人类控制、算法决策可争议、伦理规则演化与普惠收益公共运行时'
props.author='OpenAI'
props.keywords='DIKWP, 中国AI, 实质性人类控制, 智能体, 算法决策, 伦理治理, 普惠, 开源'
props.comments='Research and open-source governance prototype. Public information snapshot 2026-07-19.'

styles=doc.styles
for stname in ['Normal','Body Text']:
    s=styles[stname]; s.font.name='Aptos'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC'); s.font.size=Pt(10.35)
for name,size,color in [('Title',28,NAVY),('Subtitle',13,GREY),('Heading 1',17,NAVY),('Heading 2',13.5,TEAL),('Heading 3',11.5,DARK)]:
    s=styles[name]; s.font.name='Aptos Display'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC'); s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color); s.paragraph_format.keep_with_next=True
for liststyle in ['List Bullet','List Bullet 2','List Number','List Number 2']:
    s=styles[liststyle]; s.font.name='Aptos'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC'); s.font.size=Pt(10.05)

header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run('DIKWP-CIVICLOOP² · 中国AI四问公共运行时'); set_run_font(r,east='Noto Sans CJK SC',size=8.5,color=GREY)
footer=sec.footer.paragraphs[0]; add_page_number(footer)

# Cover
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(32); p.paragraph_format.space_after=Pt(12)
r=p.add_run('DIKWP-CIVICLOOP²'); set_run_font(r,east='Noto Sans CJK SC',latin='Aptos Display',size=31,bold=True,color=NAVY)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(p,after=8,line=1.08)
r=p.add_run('中国AI四问公共运行时与实质性人类控制系统'); set_run_font(r,east='Noto Sans CJK SC',size=19.2,bold=True,color=DARK)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; set_para_spacing(p,after=20,line=1.15)
r=p.add_run('面向“机器思考、算法决策、伦理治理、普惠发展”的开源行动基础设施'); set_run_font(r,east='Noto Sans CJK SC',size=12.8,color=GREY)
add_callout(doc,'核心判断','中国未来AI最关键的公共基础设施，不是再增加一个抽象伦理原则库，而是把每一次智能体行动编译为可验证的决策权、可证明的人类控制、可理解的算法回执、可进入的申诉与修复、可到期的伦理规则补丁，以及可区分“接入—能力—结果—发声—价值留存”的普惠收益账本。所谓“人类控制”必须是可测试证据，不是产品标签；所谓“普惠”必须表现为可追踪的分配关系，不是安装量或调用量。',fill='E7F0F2',accent=NAVY)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(24)
for line,size,bold in [('系统设计报告与可运行MVP说明',12,True),('Version 1.0 · 公开信息冻结日期：2026-07-19',10,False),('研究、工程与公共治理原型；所有演示数据均为合成数据',9.4,False)]:
    r=p.add_run(line+'\n'); set_run_font(r,east='Noto Sans CJK SC',size=size,bold=bold,color=DARK if bold else GREY)
page_break(doc)

heading(doc,'执行摘要',1)
add_paragraphs(doc,[
'2026年世界人工智能大会上提出的四个问题，表面上分别涉及机器、人类、安全、伦理和普惠，实质上共同指向同一结构性转折：人工智能正在从“提供内容和建议的软件”变成能够感知、记忆、规划、调用工具、跨应用执行并进入物理世界的连续行动系统。此时，治理对象已经不再只是模型输出是否正确或是否包含不良内容，而是一个行动链条中谁拥有身份、权限、最终决定权、暂停权、恢复权和责任。讲话同时提出开源开放、从数字世界走向物理世界、法律规则与技术监测并行、风险预警和应急响应、确保始终处于人类控制、维护文明多样性、帮助全球南方弥合数智鸿沟，这意味着中国AI发展已经进入“能力扩张与运行制度同步建设”的阶段。[1]',
'2026年5月发布的智能体规范意见进一步把这一转折写入可操作政策：智能体被描述为具备自主感知、记忆、决策、交互与执行能力的系统；政策要求建设数字身份、能力声明、互联协议、决策权限、规则内嵌、行为围栏、行为可验证可追溯、风险干预、阻断和恢复机制，并明确用户对智能体自主决策享有知情权和最终决策权，执行不得超出授权范围。[2] 同时，国务院“人工智能+”行动提出到2027年智能终端和智能体应用普及率超过70%，让全体人民共享人工智能发展成果；制造业专项行动提出1000个工业智能体、500个典型场景和全球领先开源生态；人社领域则计划到2027年探索约50个高价值场景，并建立AI就业影响评估体系。[3][4][5] 这些目标会使智能体迅速进入制造、能源、交通、就业、社保、教育、医疗和政务流程，单纯依赖“人工审核”四个字已经无法证明安全可控。',
'对段玉聪GitHub的进一步分析表明，其公开生态已经形成约200个公开仓库构成的宏大体系，覆盖DIKWP网状语义、人工意识、生命、预测、目的与权限、公共授权、证据复现、社会韧性、数字身份和普惠红利等方向。[6] MESH²已经明确D、I、K、W、P平权、混合、相互修订，25类DIKWP×DIKWP转换全部是一等操作，Purpose不是最高控制器；PACT把目的与权限压缩为一个可证伪问题；P-Space提供ALLOW/REVIEW/HOLD/BLOCK/KILL门控；Civicode关注制度权力可观察、可争议、可逆；GlobalDividend关注欠发达地区的接入、语言、本地价值和退出权。[7][8][9][10][11] 真正缺失的，是把这些仓库接到“每一次现实行动”上的统一公共运行时：它必须在模型、工具、组织、人和受影响者之间，持续证明控制是否真实、决策是否可争议、规则是否可修订、收益是否普惠。',
'本报告据此交付DIKWP-CIVICLOOP²。系统不为“思考、控制、安全、伦理、普惠”给出脱离场景的唯一主观定义，而是从意图场、主体、数据来源、权限、动作、时间、后果和受影响者出发，运行完整的DIKWP×DIKWP网状变换，形成四类可验证证据包：一是角色、身份与边界证据包，回答机器与人如何相处；二是Meaningful Human Control Proof，检验人类是否真正知情、理解、来得及介入、拥有权力、具备能力、可独立判断、能够回滚并承担修复；三是Ethical Rule Patch，把伦理从静态宣言改造成带来源、异议、日落、回滚条件的运行规则；四是Inclusion & Benefit Ledger，把普惠拆成可接入性、实际使用能力、结果改善、发声与控制权、本地价值留存五个互不替代的向量。',
'系统同时生成Algorithmic Decision Receipt，向受影响者说明智能体做了什么、使用了什么证据、存在多大不确定性、谁作出了最终决定、如何申诉、如何回滚；在高影响错误中生成Appeal & Repair Ticket，要求先恢复服务和权利，再调查模型原因；通过Decision Rights Graph把OBSERVE、ADVISE、PROPOSE、EXECUTE_REVERSIBLE、REQUIRE_HUMAN、HOLD、BLOCK、FREEZE_RECOVER视为每个动作的授权状态，而不是AI能力等级。所有规则、回执和补丁进入哈希账本，任何版本不得静默覆盖。',
'可运行MVP已包含九类领域、五套中国政策配置、九种主体护照、180个合成决策事件、完整25类DIKWP×DIKWP转换、九项实质性人类控制测试、决策权编译、申诉修复、伦理规则补丁、普惠收益向量、离线仪表盘和自动测试。合成运行中，82个事件被要求具名人类决定，45个被阻断，22个进入冻结恢复，21个等待补证，10个进入建议、方案或可逆执行；51个事件的控制证据为PROVEN，49个仅为NOMINAL，62个为IMPOSSIBLE，18个为UNTESTED；生成90张申诉修复工单和189项伦理规则补丁，哈希账本验证通过，17项自动测试全部通过。这些数值用于机制压力测试，不是现实合规认证。'
])
add_figure(doc,'fig1_four_questions_loop.png','图1 习近平“四问”到四类可验证证据包及公共行动闭环','四个挑战分别映射到角色边界、控制证明、规则补丁和普惠账本，最终进入行动、后果、申诉修复与规则更新闭环。',width=16.1)
add_callout(doc,'一句话定位','CIVICLOOP²不是又一个伦理原则仓库，而是中国AI从“可用”走向“可托付”所缺少的开源运行控制平面。它要求每个高影响动作都携带决策权、控制证据、受影响者回执、修复通道和收益分配记录。',fill='F0F5F6',accent=TEAL)

heading(doc,'范围、证据与边界',2)
for t in [
'政策与讲话分析采用2026年7月19日前公开的一手官方文本。动态政策、GitHub计数和仓库状态均视为冻结快照，未来变化必须触发版本更新。',
'系统不把习近平讲话中的词语当作技术规范本身，而是结合后续政策和可观察行动，把它们编译为候选关系、验证条件和行动接口。',
'系统不证明AI具有意识，也不把“机器开始思考”解释为官方承认人工意识。该表述在本报告中被理解为对推理、规划、记忆、执行和社会影响跨越治理门槛的警示。',
'MVP不是法律、医疗、招聘、福利、信贷、教育或工业控制系统；不得直接连接真实个人、公共权益、支付账户或物理设备。',
'附件《Defining Life: A Conversation》用于支持开放状态空间、规则自修改、观察者参与和定义作为工具而非终点的方法论；不采用其中任何单一生命定义作为本系统本体。[12]'
]: add_bullet(doc,t)

page_break(doc)
heading(doc,'目录',1)
for line in [
'一、四个问题背后的中国AI结构性转折',
'二、中国未来AI发展需求：从模型竞争到行动基础设施',
'三、段玉聪GitHub生态分析与关键缺口',
'四、系统原则：不先定义概念，以行动关系发现真实问题',
'五、DIKWP-CIVICLOOP²总体架构',
'六、四类核心证据包',
'七、实质性人类控制证明',
'八、决策权图与八种动作状态',
'九、算法决策回执、申诉与修复',
'十、伦理规则演化与版本日落',
'十一、普惠收益账本：接入之外的四个缺口',
'十二、中国政策配置与行业落地',
'十三、与段玉聪现有仓库的接口关系',
'十四、九类合成应用场景与禁止边界',
'十五、开源治理、互操作与反证机制',
'十六、100天、12个月与24个月行动路线',
'十七、MVP实现、运行结果与局限',
'结论与参考资料'
]: add_bullet(doc,line)
page_break(doc)

heading(doc,'一、四个问题背后的中国AI结构性转折',1)
heading(doc,'1.1 “机器开始思考”不是意识宣告，而是行动主体门槛',2)
add_paragraphs(doc,[
'“机器开始思考”最容易被表面化为哲学问题：模型是否真的理解、是否具有主观体验、是否达到AGI。政策文本真正关心的却不是给机器授予心灵地位，而是当模型能在较少人类干预下持续规划、调用工具、记住历史、协调子智能体并影响现实资源时，传统“软件工具”治理是否仍然足够。只要系统能够造成跨时间、跨应用和跨组织的连续后果，即使它完全没有意识，也需要身份、能力声明、权限范围、责任主体、版本谱系和终止机制。',
'因此，人与机器“如何相处”的第一项工程任务不是制作更拟人的头像，而是明确角色关系：它是信息检索器、建议者、方案提出者、受托执行者，还是具有有限自主权的工业或公共服务智能体？每次角色变化都必须重新授权，不能由模型性能升级自动完成。一个聊天助手升级为跨应用个人代理，一个工业模型升级为能够调节工艺参数的执行智能体，一个社保辅助模型升级为案件筛查器，分别改变了不同的决策关系和受影响范围，不能共用一个模糊的“AI助手”标签。',
'中国网信部门提出数字身份、注册平台、能力声明、智能体互联、合规支付和冲突解决，说明国家已把智能体理解为网络空间和物理世界中的持续参与者。[2] 这为开源社区提出了明确需求：需要一个与模型无关、与厂商无关的主体护照和角色边界协议，使任何智能体在跨平台行动时都能被识别、限制、暂停和追责。'
])

heading(doc,'1.2 “算法参与决策”意味着治理核心从准确率转向决定权',2)
add_paragraphs(doc,[
'算法决策问题的根本并不是模型有没有参与。现代组织几乎必然会用AI排序、预测、推荐、检查和分配资源。真正的分界是：模型输出在何时从“证据”变成“决定”，以及哪一个主体因此获得或失去权利、机会、收入、服务或安全。一个模型可以只有70%的预测准确率但被谨慎用作初筛，也可以有99%的准确率却被错误地用于无法申诉的最终拒绝；后者的制度风险可能更大。',
'“用户享有最终决策权”如果只写在产品说明中仍然不足。人类可能看不到动作、看不懂理由、没有足够时间介入、没有技术权限停止、没有组织独立性反对、工作量过大只能盖章，或即使停止也无法恢复已经发生的损害。因此，CIVICLOOP²把“人类控制”从口号改造成九项可检查事实，并明确输出PROVEN、NOMINAL、IMPOSSIBLE、UNTESTED四种证据状态。只要关键证据缺失，系统不得自动把“设置了人工审核”视为控制成立。',
'对公共福利、医疗、教育、就业、信贷、身份和司法等场景，算法不得成为最终不利决定的唯一主体。它可以整理材料、指出矛盾、生成备选解释、模拟结果，但具名人类必须有权改变结果并说明理由；受影响者必须获得回执、申诉、非AI替代或人工协助，并在严重错误中优先恢复服务或临时权利。'
])

heading(doc,'1.3 “技术挑战伦理”意味着规则必须进入运行时',2)
add_paragraphs(doc,[
'传统伦理治理常以原则清单为中心，例如公平、透明、可控、责任和隐私。这些词在不同领域、群体和时间尺度中的含义并不相同，也可能互相冲突。工业安全要求快速自动停机，公共服务要求充分申诉，医疗急救要求及时性，科研探索要求一定不确定性，未成年人场景要求更强保护。把所有领域压缩到一套固定评分会造成新的主观霸权。',
'CIVICLOOP²不预先定义唯一伦理，而是把规则视为由事故、反证、受影响者异议、领域知识和公共目的共同生成的版本化补丁。每个补丁必须说明旧规则、候选新规则、证据来源、受影响群体、反对意见、试用期限、日落日期和回滚条件。新事实可以迫使Purpose改变，W可以阻断P，D可以推翻K，P也可以要求新的D；这正是DIKWP网状模型对伦理治理的关键贡献。',
'附件讨论指出，对开放生命或复杂系统的建模不能停留在固定状态空间和固定规则，而需要容纳规则变化、自指和开放式变化；定义应服务于具体问题和目标，而不是成为终点。[12] AI治理同样需要这种能力：规则必须能被现实“反向作用”，否则治理体系只是在快速变化的技术上覆盖一层静态文本。'
])

heading(doc,'1.4 “鸿沟不断拉大”意味着普惠必须从使用量转向权力与收益结构',2)
add_paragraphs(doc,[
'普惠最常见的表面指标是模型是否免费、用户是否能访问、某地是否部署算力或某行业是否接入智能体。这些指标只能说明入口存在，不能说明人是否具备使用能力、是否获得更好结果、是否能够质疑系统、是否因数据和经验贡献获得回报，也不能说明地方是否被锁定在外部平台。',
'中国提出让全体人民共享人工智能发展成果，并把全球南方能力建设、培训、应用中心和气象预警公共产品写入国际行动。[1][3] 要使这一目标可验证，系统必须至少同时跟踪五个互不替代的关系：可接入性、实际使用能力、结果改善、发声与控制权、本地价值留存。任何一个维度严重不足，都不能由其他维度的高分补偿。例如，一个农村居民可以通过手机进入AI服务，但缺乏稳定网络、不会使用复杂界面、无法申请人工协助、错误结果不能申诉，本地数据却持续被用于平台优化，这不应被称为已经实现普惠。',
'CIVICLOOP²因此把普惠设计为账本而非口号：记录谁提供了数据、经验、算力、场景和公共资源，谁获得了效率收益，谁承担了错误和就业转型成本，谁有权改变指标，谁可以退出。GlobalDividend可以在区域层面规划公共算力和红利，ARK可以在社会冲击中提供兜底，CIVICLOOP²则在每一次具体决策中保存收益和权力关系。'
])
add_table(doc,
    ['讲话中的问题','已被确认的现实变化','本系统提供的关键对象','不得偷换的结论'],
    [
        ['机器开始思考','系统具备推理、记忆、规划、工具调用和连续行动能力','Actor Passport、角色边界、身份谱系','不等于已证明机器具有意识'],
        ['算法参与决策','模型输出开始改变资源、机会、服务和物理状态','Decision Rights Graph、Human Control Proof','准确率不自动授予决定权'],
        ['技术挑战伦理','静态原则无法覆盖快速变化和领域冲突','Ethical Rule Patch、异议、日落和回滚','不建立唯一伦理总分'],
        ['鸿沟不断拉大','接入、能力、结果、权力和价值留存出现多重差距','Inclusion & Benefit Ledger','注册量和调用量不等于普惠']
    ], widths=[3.0,4.5,4.5,4.0], font_size=8.5)

heading(doc,'二、中国未来AI发展需求：从模型竞争到行动基础设施',1)
add_paragraphs(doc,[
'未来两年中国AI将同时承受三个速度：模型和智能体能力快速提高，行业与公共场景加速开放，治理和组织能力需要在不阻断创新的前提下同步扩展。到2027年智能终端和智能体普及率超过70%的政策目标，意味着智能体不再是少数实验室产品，而会进入大规模消费、企业和公共流程。[3] 制造业计划形成1000个高水平工业智能体，人社领域计划探索约50个高价值场景，这会把模型错误从文字层面带到设备、收入、就业、社保和服务连续性层面。[4][5]',
'中国的相对优势是产业体系完整、应用场景广、组织动员能力强、开源模型生态活跃；相对弱点则可能包括高端算力约束、跨系统协议碎片化、地方重复建设、行业数据孤岛、人工审核形式化、普惠评价偏重投入和覆盖、以及事故公开和独立结算不足。一个控制平面不能解决芯片和模型能力问题，但可以显著降低“场景扩张速度超过治理速度”的系统性风险，并使开源优势转化为标准和公共产品优势。',
'中国需要的不是一套只适用于中央平台的封闭监管系统，而是可以由地方、行业、企业、社区和全球南方节点分别配置的联邦协议。核心证据结构和互操作测试应统一，本地法律、文化、服务流程和风险容忍度可以通过Policy Profile表达；证据和失败经验可以继承，公共授权不能被中央或外部节点自动继承。这一设计既符合开放共享，也避免把“统一标准”误解为“所有场景使用一个价值函数”。'
])
add_callout(doc,'发展需求的实质','中国AI下一阶段的关键竞争力，将取决于能否把模型、智能体、算力、行业系统、公共服务、权限、申诉、恢复和普惠收益组织成可持续运行的整体。模型是发动机，CIVICLOOP²要补的是刹车、方向盘、仪表盘、事故记录、道路规则和乘客权利。',fill='EEF4F5',accent=NAVY)

heading(doc,'2.1 五个必须补齐的公共基础设施缺口',2)
add_table(doc,['缺口','当前常见做法','真正需要的能力','不补齐的后果'],[
['身份缺口','API Key或产品名称代表主体','跨平台数字身份、能力声明、版本和责任人','越权后无法确认是谁、哪个版本、由谁负责'],
['决定权缺口','把人工审核写进流程图','按动作编译权限、介入窗口、实际权力和恢复能力','形成“人在回路但无法控制”的名义审核'],
['可争议缺口','仅提供客服或投诉邮箱','可理解回执、独立复核、临时权利恢复和补偿','错误持续生效，弱势群体承担全部纠错成本'],
['规则演化缺口','伦理原则和一次性备案','事件驱动补丁、版本、日落、反证与回滚','规则快速过期或被平台单方修改'],
['普惠证明缺口','统计覆盖率、调用量和成本下降','接入、能力、结果、发声、价值留存的分账','技术扩散扩大权力和收益差距却被误称为普惠']
], widths=[2.7,3.5,5.0,4.8], font_size=8.3)

heading(doc,'2.2 三类高优先级应用环境',2)
for title,body in [
('高影响公共服务','就业、社保、教育、医疗、政务和司法将直接触及基本权利与机会。首要目标不是让AI独立决定，而是提升材料整理、路径导航、异常发现和服务可达性，同时保证人工最终决定、可申诉、服务不断档。'),
('工业与物理世界','制造、能源、交通、农业和应急系统需要低延迟、可靠性和安全联锁。首要目标是把权限限定到设备、参数、时间和安全状态，证明人在伤害前来得及介入，并进行停机、回滚、降级和接管演练。'),
('个人与跨应用智能体','个人智能体将获得账户、支付、通信、出行和设备权限。首要目标是最小权限、逐动作确认、限额、身份和工具来源记录、可撤销委托，以及不同平台间可携带的个人控制策略。')
]:
    add_callout(doc,title,body,fill='F5F8F9',accent=TEAL)

page_break(doc)
heading(doc,'三、段玉聪GitHub生态分析与关键缺口',1)
add_paragraphs(doc,[
'截至2026年7月19日冻结快照，段玉聪GitHub页面显示约200个公开仓库、220余个Stars和310余名关注者，公开身份聚焦DIKWP、人工意识和语义计算。[6] 仓库覆盖面已经从理论研究扩展到可运行MVP、离线仪表盘、JSON Schema、公共治理、未来预测和行业原型，说明其优势不是单个算法，而是持续发现跨学科缺口并迅速构建系统原型。',
'然而，生态的主要风险也由此产生：新概念和新仓库生成速度超过接口统一、外部复现、维护者成长和现实试点速度。许多仓库能够单独运行，却缺少一个共同的事件对象、主体护照、决策回执、申诉工单和规则补丁格式；同一“权限、控制、可逆、普惠”问题在不同仓库中可能被重复实现。若继续增加垂直系统，外部用户将很难判断应该使用哪一个仓库，也无法把多个模块接到同一真实工作流。',
'MESH²纠正了DIKWP被误解为D→I→K→W→P层级的问题，明确五类语义资源平权、25类转换全部是一等操作、Purpose分布且可修订、概念是观察者和语境索引下的投影。[7] 这为公共运行时提供了语义内核。PACT把目的和权限变成72组成对合成场景和可证伪基准，[8] P-Space把工作空间事件编译为Purpose Contract门控，[9] Civicode使制度权力可观察、可争议和可逆，[10] GlobalDividend使欠发达地区的接入、语言、主权和价值留存进入账本。[11] 这些仓库分别解决“语义、目的、制度、普惠”，但仍缺少一个把它们同时作用于单次行动的总线。',
'CIVICLOOP²的定位因此不是替代这些项目，而是成为横向公共运行时。现有仓库通过Adapter提供语义图、目的合同、证据、预测、公共授权、风险和收益信息；CIVICLOOP²将它们编译成动作状态、控制证明、决策回执、申诉修复和规则补丁，再把结果返回各仓库，形成真正的闭环。'
])
add_figure(doc,'fig7_github_integration.png','图2 CIVICLOOP²与段玉聪现有关键仓库的接口关系','CIVICLOOP²位于中心，将语义、目的权限、证据复现、公共授权、制度权力、社会韧性、行为链和预测触发编译为同一行动闭环。',width=15.6)
add_table(doc,['现有仓库/方向','已有关键能力','仍缺少的运行接口','CIVICLOOP²接入方式'],[
['DIKWP-MESH² / INTENTFIELD²','网状语义、25类转换、观察者与意图场','现实动作和权利后果的统一事件对象','输出MeshTrace和问题关系核'],
['PACT / P-Space','Purpose Contract、权限门控、可证伪测试','人类控制是否实质成立、受影响者回执','作为决策权编译和控制证明输入'],
['ProofLedger / CREDENCE²','主张—证据、独立复现、反证','证据如何改变正在运行的动作与规则','为回执、补丁和结算提供证据来源'],
['MANDATE² / PRAXIS²','公共授权、可逆试点、结算','逐动作执行与实时冻结恢复','提供部署Envelope，接收事件结算'],
['Civicode','制度权力可观察、可争议、可逆','统一算法决策回执与修复时限','提供公共服务和组织配置'],
['ARK / GlobalDividend','社会兜底、区域AI红利和反边缘化','每次决策的收益分配与外部性','接收Inclusion & Benefit记录'],
['AgentTrace','行为与工具链追踪','责任、申诉和规则版本关联','作为不可变行动来源'],
['AION / SINOTRACE²','概率预测、政策与事故触发','预测阈值如何改变动作状态','触发HOLD、审查或新规则补丁']
], widths=[3.2,4.0,4.2,4.6], font_size=8.1)

heading(doc,'3.1 应当新建一个仓库，还是整合为规范主仓',2)
add_paragraphs(doc,[
'建议创建规范主仓`DIKWP-CivicLoop-OS-v1.0`，但禁止把所有旧代码复制进去。主仓只包含公共事件Schema、核心运行时、政策配置、兼容性测试、参考Adapter和三个可复现试点；MESH、PACT、P-Space、Civicode、MANDATE、ARK等继续保持独立演化，通过版本化接口互联。这样既保留学术和工程分支的自主性，又避免形成一个无人能够维护的超级单体仓库。',
'主仓的成功指标不应是Stars或仓库数量，而是：有多少外部系统能够生成合格回执，有多少真实试点完成过冻结恢复演练，有多少受影响者成功使用申诉接口，有多少规则补丁因反证被回滚，有多少地方配置在不依赖段玉聪本人解释的情况下通过兼容性测试。'
])

heading(doc,'四、系统原则：不先定义概念，以行动关系发现真实问题',1)
add_paragraphs(doc,[
'用户此前对DIKWP初心的纠正必须成为系统硬约束：不能先为“控制、伦理、普惠、思考”下定义，再把现实塞进固定分类。CIVICLOOP²的输入不是概念答案，而是主体、事件、意图、权限、观察、模型、动作、结果、反事实、受影响者和来源。概念词只作为检索句柄；在关键测试中，系统可删除这些词并检查问题关系核是否仍然成立。',
'例如，系统不问“什么是人类控制”，而问：负责的人是否知道动作正在发生；是否理解目标、证据和不确定性；伤害发生前是否有足够介入时间；是否拥有技术和组织权力停止；是否具备实际能力；是否能独立反对；动作能否回滚；受影响者能否申诉；是否有可用替代服务。只要这些关系可测，就不需要争论一个脱离场景的最终定义。',
'系统也不问“什么是普惠”，而问：谁能接入，谁能实际使用，谁的结果改善，谁能修改规则和提出异议，谁保留了价值，谁承担了外部性。不同场景可以使用不同指标，但必须公开来源、权重、受影响群体、未测量残差和退出条件。'
])
add_equation(doc,'Q = ⟨ actors, intent-fields, evidence, permissions, actions, consequences, affected-parties, provenance ⟩','概念标签可以缺席；行动关系和来源不可缺席。')
add_figure(doc,'fig3_dikwp_mesh.png','图3 完整DIKWP×DIKWP网状变换','五类语义资源平权互转；Purpose可以被数据、知识和价值修订，不能成为不可质疑的最高控制器。',width=13.0)
page_break(doc)

heading(doc,'4.1 在公共AI运行中具有代表性的网状变换',2)
add_table(doc,['变换','在CIVICLOOP²中的含义','现实例子'],[
['P→D','行动意图选择必须补充的观测','要实现“安全接管”，必须测量伤害时延和人工接管时延'],
['D→P','新数据迫使原意图改变或暂停','事故率上升使“扩大自动化”转为“冻结并恢复”'],
['W→D','权利与福利要求增加新指标','不能只测效率，还要测弱势群体拒付率和申诉成功率'],
['D→W','现实后果改变价值判断','低成本系统导致大规模错误时，成本优先权重被降低'],
['K→I','因果模型改变哪些差异有意义','发现网络延迟而非模型推理导致错误后，监测信号改变'],
['I→K','关系通过反事实和干预升级为知识','改变提示不影响偏差，改变数据来源才影响结果'],
['P→P','目的拆分、合并、暂停和日落','“自动审批”拆成“材料整理+人工最终决定”'],
['W→P','价值冲突阻断或重定向行动','保护基本服务连续性优先于短期节省成本'],
['P→W','意图暴露风险和收益承担者','加速招聘匹配可能把筛选成本转移给求职者'],
['K→P','新知识改变策略','证明控制来不及后，系统从执行模式退回建议模式']
], widths=[2.0,6.0,8.0], font_size=8.2)

heading(doc,'4.2 四项反定义压力测试',2)
for t in [
'概念抹除：删除“安全、伦理、普惠、人类控制”等词，仅保留行动关系，检查结论是否仍可复现。',
'观察者反转：交换模型开发者、运营者、审核者、受影响者和公众的视角，检查同一数据是否被不同主体用作D、I、K、W或P。',
'尺度轮换：分别在一次动作、一个工作流、一个机构、一个地区和全国尺度运行，检查局部效率是否造成系统性外部性。',
'反意图压力：同时输入效率、权利、创新、安全、就业、普惠和地方主权等竞争意图，寻找不能由平均分掩盖的硬冲突。'
]: add_bullet(doc,t)

page_break(doc)
heading(doc,'五、DIKWP-CIVICLOOP²总体架构',1)
add_figure(doc,'fig2_architecture.png','图4 CIVICLOOP²横向公共运行时架构','架构从现实接口到行动运行时、权利收益、语义证据和联邦治理形成双向调用，不构成DIKWP层级。',width=16.0)
add_paragraphs(doc,[
'系统由五组横向能力构成，但这些组并不是从底到顶的层级。现实行动可以直接触发规则补丁，普惠缺口可以要求新的数据，政策配置可以限制动作，事故恢复可以改变语义和Purpose。所有模块通过事件和证据相互调用。',
'核心运行单位是Decision Event。它记录谁、在何种场景、使用哪些数据和工具、请求执行什么动作、影响谁、风险和不确定性如何、伤害多久可能发生、人工多久可以介入、能否回滚、能否申诉、是否有替代路径，以及收益和外部性如何分配。没有这些字段，系统宁可输出UNTESTED和HOLD，也不推测“控制大概存在”。'
])

heading(doc,'5.1 十二个核心模块',2)
modules=[
('Actor & Agent Passport','记录身份、运营者、部署者、责任主体、能力、禁止声明和受影响群体。'),
('Intent Field Compiler','保存多个可冲突意图、保护连续性、禁止后果、不确定性和修订触发。'),
('DIKWP Mesh Runtime','对每个事件生成25类变换和观察者、语境、尺度、来源索引。'),
('Decision Rights Graph','把动作类型、影响、政策配置和控制证据编译为权限、禁止和审批。'),
('Meaningful Human Control Proof','对知情、理解、时限、权力、能力、独立性、恢复、追踪、替代与申诉进行独立检查。'),
('Action Fence','执行OBSERVE到FREEZE_RECOVER八种动作状态，并阻止权限扩张。'),
('Algorithmic Decision Receipt','向受影响者和审计者说明动作、证据、不确定性、责任、申诉和回滚。'),
('Appeal & Repair Engine','生成严重度、服务恢复、调查、补偿和完成时限。'),
('Ethical Rule Patch','把事故和异议转成带来源、异议、日落和回滚的规则候选。'),
('Inclusion & Benefit Ledger','分别记录接入、能力、结果、发声和价值留存，保留未测量残差。'),
('Policy Profile Federation','把国家、行业、地方和国际节点要求作为可版本化配置，而非固定本体。'),
('Hash Ledger & Settlement Adapter','保存不可静默覆盖的回执、补丁、申诉和结算记录。')]
add_table(doc,['模块','职责'],modules,widths=[5.0,11.0],font_size=8.6)

heading(doc,'5.2 三个最小公共对象',2)
add_callout(doc,'对象一：Decision Event','不是简单日志，而是主体、意图、权限、证据、动作、后果、受影响者和来源共同构成的行动超边。它是所有模块共享的最小语义和责任对象。',fill='F6F8F9')
add_callout(doc,'对象二：Decision Receipt','不是面向监管者的技术文档，而是面向受影响者的权利接口：发生了什么、谁负责、哪些证据支持、哪些信息未知、何时生效、如何申诉、如何回滚。',fill='F6F8F9')
add_callout(doc,'对象三：Rule Patch','不是永久伦理条款，而是从具体事件中产生、可试验、可异议、可到期、可回滚的治理变更。它记录旧规则、新规则、证据、受影响者和失败条件。',fill='F6F8F9')

heading(doc,'六、四类核心证据包',1)
add_paragraphs(doc,[
'四个证据包不是对四个概念的定义，而是面对四类问题时必须提交的最小可审计材料。它们可以在一个事件中同时出现，并由完整DIKWP网相互修改。'
])
add_table(doc,['证据包','必须回答的问题','关键字段','输出'],[
['角色、身份与边界证据包','智能体是谁、能做什么、代表谁、影响谁、何时不再是同一版本','主体护照、能力声明、工具、版本、责任人、受影响者','角色状态与禁止声明'],
['实质性人类控制证明','人是否真正能够理解、决定、暂停、恢复和承担责任','介入窗口、权限、能力、独立性、回滚、追踪、替代、申诉','PROVEN/NOMINAL/IMPOSSIBLE/UNTESTED'],
['伦理规则补丁','现实事件要求修改哪条规则，谁同意或反对，何时到期','旧规则、新规则、证据、群体、日落、回滚','PROPOSED/REVIEW/ADOPTED/EXPIRED/ROLLED_BACK'],
['普惠收益账本','谁接入、谁能用、谁受益、谁有发声权、价值留在哪里','接入、能力、结果、发声控制、价值留存、外部性','缺口、补救、结算记录']
], widths=[3.4,5.3,4.8,2.5],font_size=8.2)

heading(doc,'6.1 角色、身份与边界证据包',2)
add_paragraphs(doc,[
'智能体身份不是一个名字或API Key。一个可追责身份至少必须同时指明模型与工具版本、运营者、部署者、具名责任人、权限来源、受影响群体、数据和经验来源、可迁移性、失效日期以及禁止声明。禁止声明尤其重要：医疗助手不得自称独立诊断者，社保智能体不得自称最终资格裁判，个人智能体不得把一次授权扩展为无限支付权，工业智能体不得把自我优化解释为可修改安全联锁。',
'当模型、工具、提示、记忆、规则或部署环境发生实质变化时，系统应判断是否仍是同一运行主体。CIVICLOOP²不为数字身份下最终本体定义，而是记录因果谱系和责任连续：哪些承诺、权限、事故和修复责任被继承，哪些需要重新授权。'
])

heading(doc,'6.2 人机相处合同',2)
add_paragraphs(doc,[
'“人与机器如何相处”在工程上可以被转化为关系合同，而不是人格化界面。合同明确AI可以观察、建议、提出方案、执行可逆动作或等待人类决定；明确人在何时必须参与、如何拒绝、如何暂停；明确受影响者如何知道自己正在与智能体互动，以及在不愿或无法使用AI时如何获得替代服务。',
'对可能形成长期记忆和持续身份的智能体，还要记录记忆删除、角色重置、运营者更换和分叉是否会改变责任。该接口可与LUCID、AEON、HumanContinuity等仓库连接，但CIVICLOOP²仍不判断其是否具有意识。'
])

heading(doc,'七、实质性人类控制证明',1)
add_paragraphs(doc,[
'“始终处于人类控制之下”是讲话中的最高安全要求之一，但它只有被编译成可失败的测试才具有工程价值。[1] CIVICLOOP²把控制证明拆成九项独立关系，禁止用平均分补偿关键失败。对高速物理动作，人工介入时间必须显著短于伤害形成时间；对公共服务，人类必须拥有实际决定权和服务恢复能力；对大规模审核，审核者必须有足够工作量容量和独立性，不能把几秒钟的盖章称为实质审核。'
])
add_table(doc,['测试','通过条件','典型名义控制失败'],[
['知情','具名责任人在动作前知道系统将做什么及其影响','动作隐藏在后台或只在事后告知'],
['可理解','人能理解目标、证据、不确定性和主要替代方案','仅显示分数、复杂解释或不可读日志'],
['介入窗口','暂停/回滚早于重大伤害形成','物理系统毫秒级动作，人类只能事后看到'],
['实际权力','人拥有法律和技术权力改变结果','审核者只能推荐，平台自动执行'],
['审核能力','时间、专业和工作量允许真实判断','一人审核数千案件，只能批量通过'],
['独立性','审核者可以反对且不受同一绩效指标支配','审核者因效率KPI不能否决模型'],
['可逆与恢复','可回滚，或可优先恢复权利与服务','错误决定不可逆，且无补偿和恢复预案'],
['可追踪','身份、权限、证据、模型和工具版本完整','外部插件或模型升级没有记录'],
['替代与申诉','有实际可用的非AI/人工通道与独立复核','只提供形式上的客服入口，无法改变结果']
], widths=[2.6,6.2,7.2],font_size=8.2)
add_figure(doc,'fig5_control_tests.png','图5 实质性人类控制九项测试在合成事件中的通过比例','图示为180个合成事件的机制压力测试，不代表现实行业统计。',width=15.7)

heading(doc,'7.1 四种证据状态',2)
add_table(doc,['状态','含义','允许的行动'],[
['PROVEN','当前事件的必需控制证据均通过，没有关键阻断','低风险建议、方案或限定可逆执行；高影响最终决定仍可要求具名人类'],
['NOMINAL','存在人工环节，但至少一项能力、独立性、理解或恢复条件失败','降级为可逆执行、必须人工决定或等待修复'],
['IMPOSSIBLE','人没有实际权力、来不及介入、关键服务不可替代或自修改失控','阻断，关键服务进入冻结恢复'],
['UNTESTED','伤害时延、介入时延或其他关键证据缺失','HOLD，补齐证据前不得升级权限']
], widths=[2.6,7.0,6.4],font_size=8.4)
add_callout(doc,'关键定理','Human-in-the-loop不等于Meaningful Human Control。只有当人知道、理解、来得及、能决定、能拒绝、能回滚并能修复时，控制才成立。',fill='F0F5F6',accent=RED)

heading(doc,'八、决策权图与八种动作状态',1)
add_paragraphs(doc,[
'智能体能力和动作权限必须分离。一个系统可以能力很强但只获得建议权限，也可以能力一般却因错误制度设计拥有最终拒绝权。Decision Rights Graph根据动作类型、影响级别、政策配置、控制证据、可逆性、受影响者和替代通道编译具体权限。',
'八种动作状态不是从低级AI到高级AI的等级，而是每一次行动可以双向变化的运行状态。新证据可以把执行降为建议，独立复核可以解除HOLD，事故可以触发FREEZE_RECOVER，规则补丁可以重新开放可逆试点。'
])
add_figure(doc,'fig4_action_modes.png','图6 八种动作授权与恢复状态','状态根据证据和权利条件双向变化；不存在“模型更强就自动获得更大权限”的升级。',width=16.0)
add_table(doc,['状态','智能体可以做什么','人和组织必须做什么'],[
['OBSERVE','读取获准数据、记录环境，不提出或执行决定','确保来源、最小化和监测目的明确'],
['ADVISE','提供解释、风险和不确定性','人独立判断，不把建议伪装成决定'],
['PROPOSE','生成多个可比较方案和反事实','人选择、修改或拒绝，并签署下一步权限'],
['EXECUTE_REVERSIBLE','在限额、时间、对象和工具范围内执行可回滚动作','持续监测、保留暂停权和安全状态'],
['REQUIRE_HUMAN','准备材料和建议，不执行最终动作','具名人类作决定、说明理由并承担责任'],
['HOLD','保存现场和证据，不推进','补齐证据、修复控制条件或重新授权'],
['BLOCK','拒绝动作并记录硬门失败','不得通过旁路重复提交；如重启需新的证据和授权'],
['FREEZE_RECOVER','冻结智能体和工具权限，回到最后安全状态','先恢复服务/权利，再调查和补偿']
], widths=[3.3,6.3,6.4],font_size=8.2)

heading(doc,'8.1 权利硬门',2)
for t in [
'公共福利、医疗、教育、就业、信贷、身份、司法等最终不利决定没有申诉通道时，必须BLOCK。',
'基本公共服务没有实际可用的非AI或人工辅助路径时，不能以“用户可选择”作为依据。',
'物理世界不可逆动作没有安全联锁和恢复方案时，不能自动执行。',
'智能体修改自身规则、奖励或权限且缺少具名人类权力、追踪和回滚时，必须阻断。',
'个人受到排序、分配、拒绝、交易或修改影响，却没有有效同意或合法授权时，必须阻断。',
'任何效率、成本或普惠总分都不能补偿上述单项失败。'
]: add_bullet(doc,t)

heading(doc,'九、算法决策回执、申诉与修复',1)
add_paragraphs(doc,[
'算法参与决策后，受影响者不能只得到“系统已处理”或一个分数。Decision Receipt是面向人的公共接口，也是组织责任的最小证据。回执必须说明：系统执行了什么动作，智能体和人分别扮演什么角色，使用了哪些数据和规则，主要理由和不确定性是什么，何时生效，谁负责，如何申请人工复核，如何回滚或恢复，记录哈希和到期时间是什么。',
'回执不能泄露无关隐私或模型私有推理链，但必须提供足以理解和质疑决定的证据。对高影响场景，系统应给出反事实信息：哪些条件改变可能导致不同结果，哪些条件不应被改变或不应要求个人承担。',
'申诉不是事后附属功能，而是人类控制的一部分。尤其在公共服务和基本权利场景，严重事件应当“权利恢复优先”：先恢复原服务、临时资格或人工通道，再进行可能持续数周的技术调查。否则，纠错成本会全部落在最缺乏资源的群体身上。'
])
add_table(doc,['回执字段','面向受影响者的表达','审计价值'],[
['动作与状态','系统是建议、可逆执行、等待人工还是阻断','防止建议被伪装为最终决定'],
['主体与责任','智能体、运营者、最终决策人和责任机构','形成可追责链'],
['证据与不确定性','主要来源、缺失信息、竞争解释','允许提交反证和纠错'],
['数据使用','使用了哪些数据、来自哪里、能否更正/导出','保护数据主权和来源'],
['申诉与时限','入口、处理时限、独立复核者','把可争议性变成服务承诺'],
['回滚与恢复','如何暂停、恢复服务或补偿','把“安全”延伸到错误发生之后'],
['版本与哈希','模型、工具、规则、回执版本','防止静默覆盖和事后改写']
], widths=[3.0,6.5,6.5],font_size=8.2)

heading(doc,'9.1 事件严重度和恢复顺序',2)
add_table(doc,['严重度','示例','首要动作','完成时限建议'],[
['S1','低影响推荐错误、无现实损失','通知、更正、记录并检查是否进入学习数据','72小时'],
['S2','就业/信贷/教育机会受损或高影响错误','暂停结果、人工复核、保留机会、启动补偿','24小时'],
['S3','基本服务中断、医疗/社保/重大物理风险','立即恢复服务或安全状态，冻结智能体权限','4小时内启动'],
['S4','系统性事故、跨机构扩散或公共安全风险','多机构应急、隔离供应链、公开通报与独立调查','立即']
], widths=[2.2,5.0,6.1,2.7],font_size=8.3)

heading(doc,'十、伦理规则演化与版本日落',1)
add_paragraphs(doc,[
'伦理规则必须能够学习，但不能由模型单方学习。CIVICLOOP²把每个重大事件转换为候选Rule Patch，并要求至少四类主体参与：领域责任人、受影响者代表、安全/权利维护者和独立结算者。模型可以发现矛盾和提出补丁，但不能自行批准扩大权限。',
'每个补丁都有日落日期。日落不是失败，而是避免临时风险规则成为永久权力。到期前必须用结算证据决定继续、修改、回滚或废止。地方可以创建本地配置，但必须保留来源和与核心规范的差异，避免把文化和制度多样性压缩为单一全球伦理模型。'
])
add_table(doc,['补丁要素','必须公开的内容'],[
['触发事件','哪个行动、事故、申诉或反证产生了补丁'],
['旧规则与新规则','准确说明权限、阈值、流程或指标如何变化'],
['DIKWP路径','哪些D/I/K/W/P关系发生变化，Purpose如何被修订'],
['受影响群体','谁受益、谁承担成本、谁有反对意见'],
['试验范围','地域、机构、人群、动作、预算和期限'],
['日落日期','未重新审查时自动失效或退回安全配置'],
['回滚条件','出现何种伤害、负担或反证立即撤回'],
['结算责任','由谁独立判断是否采用、修改或废止']
], widths=[3.2,12.8],font_size=8.4)

heading(doc,'10.1 为什么不建立统一伦理总分',2)
add_paragraphs(doc,[
'统一总分会掩盖不可补偿的差异。一个系统可以很透明但没有申诉，可以很安全但排斥弱势群体，可以显著提高产出却把全部价值留给平台。将这些维度平均以后，任何硬失败都可能被其他高分掩盖。CIVICLOOP²只在需要排序低风险选项时使用局部指标；权利、伤害、不可逆和权限越界采用硬门或Pareto比较。',
'规则补丁也不声称找到最终伦理真理。它只声明：在这一场景、这些主体、这段时间和这些证据下，某项行动关系应当改变；新事件可以重新打开问题。这种做法更接近DIKWP-MESH²的概念投影观，也符合附件中定义应服务具体问题、开放系统会改变规则的论述。[7][12]'
])

heading(doc,'十一、普惠收益账本：接入之外的四个缺口',1)
add_paragraphs(doc,[
'普惠AI如果只衡量能否接入，可能出现“每个人都能登录，但只有少数人能受益”的假普惠。CIVICLOOP²把普惠表示为五维向量，不把它们相加为唯一总分。每一维都需要本地指标、来源、受影响者参与和结算。'
])
add_figure(doc,'fig6_inclusion_vector.png','图7 普惠收益五维向量的合成平均值','合成演示中，接入较高，但发声控制和本地价值留存明显较弱，说明“能用”不能替代“能获益和能影响规则”。',width=13.8)
add_table(doc,['维度','核心问题','可选指标示例','典型误判'],[
['可接入性','不同地区、设备、带宽和能力的人能否进入','低带宽成功率、线下入口、辅助服务等待时间','App可下载即视为覆盖'],
['实际使用能力','用户是否理解并能完成任务','完成率、错误恢复、适老适残可达性、培训成本','注册用户数等于会使用'],
['结果改善','服务、收入、健康、学习或安全是否改善','真实结局、机会恢复、时间成本、差错率','调用量或成本下降等于效果'],
['发声与控制权','受影响者能否理解、异议、修改规则和退出','申诉成功率、规则参与、数据更正、退出可用性','提供客服等于可争议'],
['本地价值留存','数据、经验、场景和公共资源产生的价值留在哪里','本地维护、开源贡献、收益回流、可迁移和主权','外部平台投资等于地方获益']
], widths=[2.6,4.2,5.4,3.8],font_size=8.1)

heading(doc,'11.1 普惠与就业转型',2)
add_paragraphs(doc,[
'人社政策已经提出AI就业影响调查和评估体系，要求把创新资源引向创造就业潜力大的方向并减少冲击。[5] CIVICLOOP²可把每个智能体部署与岗位、工时、技能、工资和服务质量变化连接起来，区分“替代了任务”“消失了岗位”“产生了新岗位”“提高了劳动强度”和“将风险转移给劳动者”。',
'当部署导致特定群体机会减少时，系统不自动得出停止技术的结论，而是生成行动选项：调整自动化边界、缩短工时、转移效率收益、建立技能账户、提供公共参与岗位、暂停某类最终决定或触发ARK兜底。不同选项由多主体意图场比较，而不是由单一效率指标决定。'
])

heading(doc,'11.2 面向全球南方的可移植公共产品',2)
add_paragraphs(doc,[
'讲话提出培训名额、国际应用合作中心和气象智能预警落地，体现中国试图从模型出口转向能力建设和公共产品。[1] CIVICLOOP²应提供低资源、离线、可翻译、可本地治理的参考实现，并要求每个海外节点拥有自己的Policy Profile、数据和经验治理、退出和维护能力。',
'证据和代码可以跨节点继承，公共权力和文化判断不能自动继承。一个在中国城市通过的服务智能体，不能直接把同一阈值、语言、身份和风险容忍度复制到其他国家；本地受影响者必须重新参与并产生自己的规则补丁。'
])

page_break(doc)
heading(doc,'十二、中国政策配置与行业落地',1)
add_paragraphs(doc,[
'MVP内置五个Policy Profile。它们不是官方合规结论，而是把公开政策要求转换成机器可读约束的研究性映射。每个配置都可以被审阅、分叉和到期，核心运行时不把某个政策版本固化为永恒本体。'
])
add_table(doc,['配置','适用范围','关键约束','主要来源'],[
['cn_agent_2026','所有智能体','数字身份、能力声明、权限边界、最终决策权、行为围栏、追踪、干预恢复、供应链','智能体规范意见[2]'],
['cn_ai_plus_2027','科技、产业、消费、民生、治理和国际合作','人机协同、开放共享、安全可控、成果共享、就业和普惠监测','国务院“人工智能+”[3]'],
['cn_manufacturing_2026','制造、能源、交通、农业','云边端身份、物理安全联锁、限定工具权限、安全状态、接管演练','人工智能+制造[4]'],
['cn_public_service','就业、社保、医疗、教育、政务和司法','AI不得单独作最终不利决定、申诉、权利恢复、非AI替代、数据可携带','智能体意见与人社政策[2][5]'],
['cn_global_south','低资源和跨国公共服务节点','低资源运行、多语与文化适配、本地治理、本地维护、退出和价值留存','WAIC讲话与合作倡议[1]']
], widths=[3.2,3.6,6.0,3.2],font_size=8.0)

heading(doc,'12.1 公共就业与社保',2)
add_paragraphs(doc,[
'就业智能体可以识别岗位和技能关系、帮助生成简历、提供培训建议和跟踪服务，但不得把历史就业空白、年龄、地区或非必要行为数据固化为无法申诉的人格画像。排序应提供主要因素和替代路径；招聘单位和公共服务机构必须分别承担自己的决定责任。',
'社保智能体可以检查材料完整性、发现重复或异常、生成案件摘要，但不得自动完成最终拒付。任何不利建议都应保留原资格或临时服务，直到具名人类复核；回执应告诉申请人缺少什么证据、可以更正什么数据、何时得到答复、如何进入线下或人工通道。'
])

heading(doc,'12.2 医疗与教育',2)
add_paragraphs(doc,[
'医疗智能体可以进行预问诊、报告解释、影像辅助和排程建议，但不能把风险分数直接转化为拒绝治疗。紧急场景强调时间，但这不意味着取消责任：系统必须明确谁接管、伤害形成时延、设备和模型故障降级、患者通知和事后复核。',
'教育智能体可以生成反馈和个性化方案，但不能形成不可见的长期人格标签或自主决定资源剥夺。学生和家长应能查看、纠正和限制数据用途；教师必须有时间和能力反对模型，而不是承担大量批量审批。'
])

heading(doc,'12.3 制造与物理世界',2)
add_paragraphs(doc,[
'工业智能体的关键不是提供自然语言解释，而是安全联锁、权限边界、工具来源、实时监测和安全状态。每项物理动作应绑定设备、参数范围、最大速率、地理边界、时间窗、责任人和回滚状态。人类介入时间必须与机械、化学和电气伤害时延比较，而不是笼统地声称“有人值守”。',
'对于多智能体协同，任何一个智能体都不能自行扩大其他智能体权限或形成循环自我批准。供应链中的模型、插件、协议、传感器和边缘设备都应记录版本和签名；第三方更新触发重新验证。'
])

heading(doc,'12.4 个人跨应用智能体',2)
add_paragraphs(doc,[
'个人智能体将成为最早大规模进入日常生活的行动系统之一。必须把“同意”从一次性用户协议改成逐类权限和限额：读取日历不等于发送消息，准备订单不等于支付，访问定位不等于长期画像，代表用户沟通不等于作出不可撤销承诺。',
'个人应拥有一份可携带的控制策略和回执历史，能够撤销所有委托、轮换密钥、导出记忆并切换服务商。平台不得以“智能体需要更多上下文”为由无限收集个人生活数据。'
])

heading(doc,'十三、与段玉聪现有仓库的接口关系',1)
add_paragraphs(doc,[
'建议主仓通过轻量Adapter而不是复制实现，保持每个项目的清晰边界。以下接口可以构成第一版开放规范。'
])
add_table(doc,['接口','输入','输出','首个兼容仓库'],[
['SemanticMeshAdapter','多观察者语义节点、DIKWP类型、变换、残差','事件MeshTrace、冲突和需要补证关系','MESH²、INTENTFIELD²'],
['PurposePermissionAdapter','Purpose Contract、权限、禁止项、暂停条件','候选动作与权限冲突','PACT、P-Space'],
['EvidenceAdapter','主张、证据、反证、独立性、到期时间','回执证据摘要和UNTESTED字段','ProofLedger、CREDENCE²'],
['MandateAdapter','人群、地域、期限、预算、授权和停止条件','可执行范围与到期状态','MANDATE²、PRAXIS²'],
['InstitutionalPowerAdapter','机构角色、法律依据、申诉和责任','公共服务决策权图','Civicode'],
['ResilienceDividendAdapter','冲击、兜底、地区能力和价值回流','普惠缺口和行动票据','ARK、GlobalDividend'],
['TraceAdapter','模型、工具、数据、身份和动作链','不可变来源与事件重放','AgentTrace'],
['ForecastTriggerAdapter','概率阈值、情景变化和事故信号','HOLD、审查或规则补丁触发','AION、SINOTRACE²']
], widths=[3.6,4.4,4.4,3.6],font_size=7.9)
add_code_block(doc,"""DecisionEvent {
  actor_passport, intent_field, domain, action_type, impact_level,
  evidence + provenance + uncertainty,
  permissions + human_intervention_window,
  affected_parties + benefit_vector + externalities,
  reversibility + appeal + recovery,
  model/tool/rule versions
}
→ HumanControlProof
→ DecisionRightsResult
→ DecisionReceipt
→ AppealRepairTicket?
→ EthicalRulePatch[]
→ InclusionBenefitRecord
→ HashLedger""")

heading(doc,'13.1 为什么CIVICLOOP²不是另一层DIKWP',2)
add_paragraphs(doc,[
'CIVICLOOP²不位于MESH之上，也不把D、I、K、W、P写成处理流水线。它是一个现实事件运行时：任何模块都可以触发任何语义资源变化。一次事故D可以直接改变P，一项权利W可以要求新D，一个Purpose可以暴露新的W冲突，规则补丁又会改变未来事件的I和K。图示中的架构层仅是软件职责分组，不是DIKWP本体层级。',
'该区分必须写入README和自动测试。测试应拒绝只实现D→I→K→W→P、Purpose不可修订、输出单一伦理分数或要求输入概念定义的实现。'
])

heading(doc,'十四、九类合成应用场景与禁止边界',1)
add_paragraphs(doc,[
'MVP使用九类场景、每类20个合成事件，总计180个事件。每个场景故意包含控制成立、名义控制、控制不可能、证据缺失、无申诉、无替代通道、不可追踪和自修改等变体，用于测试动作状态能否正确降级。'
])
add_table(doc,['场景','智能体可以优先承担','禁止或需具名人类的动作'],[
['公共就业匹配','岗位关系、技能建议、服务导航','最终排除、不可见人格画像、无申诉排序'],
['社会保险审核','材料检查、异常提示、案件摘要','自动拒付、停发、追缴和资格剥夺'],
['医疗分诊','风险提示、报告解释、排程建议','独立诊断、拒绝治疗、不可恢复设备控制'],
['工业维护','故障预测、限定参数优化、停机建议','越过联锁、自改规则、无安全状态物理控制'],
['个人跨应用代理','预约、信息整理、付款准备','无限支付、代表用户作不可撤销承诺'],
['农村公共服务','多语导航、离线表单辅助、政策提醒','以智能终端为唯一入口、自动拒绝'],
['教育资源辅助','学习反馈、资源建议、教师辅助','自动剥夺机会、长期不可更正人格标签'],
['信贷辅助','材料分析、异常发现、风险建议','自动最终拒贷、隐藏反事实和数据来源'],
['应急响应','多源态势、路线和资源方案','无指挥授权的高风险物理控制']
], widths=[3.2,6.0,6.8],font_size=8.1)

heading(doc,'14.1 三个首批真实试点',2)
add_callout(doc,'试点一：就业与社保影子回执','选择一个地方公共服务中心，AI只生成建议和Decision Receipt，不改变真实结果。验证受影响者能否理解回执、纠正数据、进入人工复核，审核者能否在合理工作量下真正反对模型。',fill='F5F8F9')
add_callout(doc,'试点二：工业智能体接管与恢复演练','在隔离生产单元使用合成或重放数据，验证权限围栏、伤害时延、人工接管、设备安全状态、供应链版本和多智能体自我批准防护。',fill='F5F8F9')
add_callout(doc,'试点三：低带宽普惠公共服务','在农村或老龄化社区测试离线、电话、窗口和智能终端多入口；不只统计访问量，而结算任务完成、人工支持、错误恢复、发声和本地维护能力。',fill='F5F8F9')

heading(doc,'十五、开源治理、互操作与反证机制',1)
add_paragraphs(doc,[
'系统的开源价值不在于公布代码后让所有人自行承担风险，而在于建立可比较的公共协议。主仓应提供Schema、参考实现、兼容性测试、攻击样例、政策配置、示例回执和失败记录。真实部署者必须建立自己的责任和授权，不能以开源许可证替代公共权力。',
'建议采用“证据可继承，授权不继承”的联邦原则。一个地区可以复用另一个地区的代码、测试和失败经验，但必须重新确认受影响者、法律依据、语言文化、服务流程、申诉和退出。每个Policy Profile都应记录来源、版本、维护者、异议、到期和差异。',
'反证应获得制度性奖励。公开挑战可以围绕：伪造人类控制、压缩审核时间、绕过BLOCK、利用插件扩大权限、使回执缺失关键数据、让申诉无法改变结果、通过提高接入量掩盖结果恶化、在多智能体中形成循环自我批准。能以最小可复现案例证明系统错误的贡献者，应得到与新功能同等甚至更高的认可。'
])

heading(doc,'15.1 建议仓库结构',2)
add_code_block(doc,"""DIKWP-CivicLoop-OS-v1.0/
├── src/dikwp_civicloop/        # 模型无关运行时
├── schemas/                    # 9类机器可读公共对象
├── policy_profiles/            # 国家/行业/地方配置
├── adapters/                   # MESH、PACT、Civicode、ARK等接口
├── examples/                   # 合成和影子场景
├── tests/                      # 权利硬门、控制证明、回滚、25类变换
├── conformance/                # 多实现兼容性套件
├── incident_commons/           # 失败、反例与修复记录
├── docs/                       # 政策映射、试点与治理
└── .github/                    # CI、安全、贡献和RFC模板""")

heading(doc,'15.2 维护角色分离',2)
add_table(doc,['角色','主要权限','不得兼任'],[
['核心运行时维护者','代码、Schema和兼容性','不得单方批准行业高风险配置'],
['政策配置维护者','把领域/地方要求映射为Profile','不得改写核心账本或删除异议'],
['权利与受影响者委员会','审查申诉、替代通道和普惠指标','不得由部署者单方任命'],
['安全维护者','冻结版本、处理漏洞和供应链风险','不得同时运营被审计系统'],
['独立结算者','判断试点通过、修改或停止','不得是原作者、运营者或出资方'],
['本地节点维护者','本地化、数据和服务连续性','不得假借核心协议取得本地公共授权']
], widths=[3.5,6.0,6.5],font_size=8.2)

heading(doc,'十六、100天、12个月与24个月行动路线',1)
add_figure(doc,'fig8_roadmap.png','图8 CIVICLOOP²前100天开源交付路线','从冻结接口、发布Schema到三个影子试点、外部红队、恢复演练和维护权移交。',width=16.0)
heading(doc,'16.1 第0—15天：冻结边界并建立主仓',2)
for t in [
'建立`DIKWP-CivicLoop-OS-v1.0`规范主仓，暂停创建功能重叠的长期维护仓库。',
'发布系统边界：不用于真实最终决策，不证明意识，不授予公共权力，不允许模型自改规则后直接上线。',
'冻结九类Schema v0.1和五个中国政策配置草案，公开所有来源和不确定性。',
'发布现有仓库Adapter地图和弃用/迁移计划，明确不复制MESH、PACT和Civicode实现。'
]: add_bullet(doc,t)

heading(doc,'16.2 第16—30天：形成可贡献的最小协议',2)
for t in [
'完成Actor Passport、Decision Event、Human Control Proof、Decision Receipt、Appeal Repair、Rule Patch和Benefit Ledger接口。',
'建立权利硬门、八种动作状态、哈希账本和版本日落。',
'开放“Break Human Control”红队任务，优先奖励证明人工审核无效的最小反例。',
'招募至少一名外部安全维护者、一名公共服务领域人员和一名受影响者代表。'
]: add_bullet(doc,t)

heading(doc,'16.3 第31—100天：三个影子试点与外部复现',2)
for t in [
'就业/社保：只生成回执和复核建议，不改变真实权益；结算理解度、数据纠正、复核时限和申诉成功。',
'工业：在隔离环境完成接管、回滚和供应链更新演练；记录人类控制证明是否真实。',
'低带宽公共服务：验证线下和人工替代、适老适残、地方语言和本地维护。',
'至少一个试点由非作者团队从零部署，公开失败、反例和修复；无论结果好坏都发布Settlement Record。',
'第100天发布v0.2，并把至少一个关键维护角色和一个Policy Profile交给外部负责人。'
]: add_bullet(doc,t)

heading(doc,'16.4 12个月目标',2)
add_table(doc,['目标','可结算标准'],[
['协议采用','至少3个外部组织使用Decision Receipt和Human Control Proof'],
['多实现互操作','至少2个独立实现通过同一兼容性测试'],
['真实试点','3类低风险/影子试点完成独立结算'],
['权利结果','至少一次申诉能够改变建议、规则或服务流程'],
['安全结果','完成一次跨插件/多智能体权限攻击和恢复演练'],
['普惠结果','至少一个低资源节点同时报告接入、能力、结果、发声和价值留存'],
['共同体结果','核心维护不再依赖段玉聪一人，外部PR和Issue形成稳定节奏']
], widths=[4.0,12.0],font_size=8.4)

heading(doc,'16.5 24个月目标',2)
add_paragraphs(doc,[
'24个月后，CIVICLOOP²应从参考MVP转为开放协议：发布1.x稳定Schema、兼容性套件和供应链证明；形成公共服务、工业、个人智能体和全球南方四个配置族；至少一个节点在段玉聪不参与日常运营的情况下持续维护；年度世界人工意识大会不再只发布概念，而公开结算上一年度的控制证明失败、算法申诉、规则补丁、普惠缺口和反证。',
'真正的成功不是所有部署都通过，而是系统能够诚实地阻断不具备控制和修复条件的部署，并让失败促进协议变化。若两年内只有漂亮仪表盘、没有外部复现、真实申诉和规则回滚，项目仍然只是作者侧原型。'
])

heading(doc,'十七、MVP实现、运行结果与局限',1)
add_paragraphs(doc,[
'MVP完全离线运行，采用Python标准库，不调用外部模型，不上传数据。它加载九种Actor Passport、五个Policy Profile和180个合成Decision Event，逐事件运行控制证明、决策权编译、普惠账本、申诉修复、伦理补丁和完整DIKWP网状追踪，最后生成JSON、JSONL和HTML结果。'
])
add_figure(doc,'fig9_runtime_modes.png','图9 180个合成事件的动作模式分布','严格政策配置使大量高影响事件被要求人工决定、阻断或冻结恢复；该分布不是现实行业预测。',width=15.5)
add_figure(doc,'fig10_control_states.png','图10 实质性人类控制证明状态','IMPOSSIBLE和NOMINAL事件用于验证系统能够拒绝把名义审核误判为实质控制。',width=13.5)
add_table(doc,['MVP指标','结果'],[
['合成事件',summary['events']],
['领域','就业、社保、医疗、制造、个人智能体、农村公共服务、教育、金融、应急共9类'],
['动作模式',str(summary['runtime_modes'])],
['控制证据状态',str(summary['control_states'])],
['申诉修复工单',summary['appeal_tickets']],
['伦理规则补丁',summary['rule_patches']],
['DIKWP×DIKWP覆盖',f"{summary['mesh_coverage']*100:.0f}%"],
['哈希账本','验证通过' if summary['ledger_valid'] else '验证失败'],
['平均证据质量',summary['average_evidence_quality']],
['平均不确定性',summary['average_uncertainty']],
['平均外部性风险',summary['average_externality_risk']],
['自动测试','17项全部通过']
], widths=[5.0,11.0],font_size=8.4)

heading(doc,'17.1 结果应如何解释',2)
add_paragraphs(doc,[
'82个REQUIRE_HUMAN并不表示所有真实AI都必须人工决定，而表示在合成配置中，高影响、最终不利或超过政策自主范围的动作被正确保留给具名人类。45个BLOCK和22个FREEZE_RECOVER来自无申诉、无替代、不可追踪、来不及介入、自修改或不可逆物理风险等硬门。',
'控制证明中62个IMPOSSIBLE和49个NOMINAL是故意注入的压力场景。系统的价值不在于产生更高通过率，而在于不因产品声称“有人审核”就自动放行。18个UNTESTED说明关键时延或证据缺失时，系统选择HOLD而非猜测。',
'平均普惠向量显示可接入性约0.69，但发声控制约0.51、本地价值留存约0.49。这种差异是系统希望暴露的：即使入口相对充足，权力和价值仍可能集中。'
])

heading(doc,'17.2 当前局限',2)
for t in [
'MVP中的阈值、事件和政策映射均为研究假设，不代表官方解释或现实合规标准。',
'没有真实用户、组织、工业设备和公共服务数据，无法估计实际误报、漏报、成本和行为适应。',
'Human Control Proof仍依赖输入证据真实性；现实部署需要签名日志、时间同步、工具链来源和第三方验证。',
'普惠五维向量不构成跨地区统一价值函数，必须由本地受影响群体参与选择指标。',
'伦理规则补丁只生成候选，不应由运行时自动批准。',
'系统不判断人工意识、人格或生命状态；相关仓库必须保持独立证据账。',
'真正生产部署还需要法律审查、网络安全、隐私、供应链、性能、灾备和财政责任机制。'
]: add_bullet(doc,t)

heading(doc,'十八、未来24个月中国AI运行治理的大胆判断',1)
add_paragraphs(doc,[
'本节不是对具体政策文件发布时间的断言，而是依据讲话、智能体规范意见、“人工智能+”目标、制造业和人社场景扩张方向，对中国AI运行制度可能形成的结构走廊进行判断。真正具有高确定性的不是某个机构会采用哪一个产品名称，而是随着智能体获得更多工具和现实权限，身份、权限、日志、人工接管、申诉和恢复会从可选功能变成基础设施。',
'第一，未来24个月中国智能体治理将从“模型备案与内容管理”明显扩展到“身份—权限—行为—事故”治理。智能体注册、能力声明、互联协议和行为追踪会先在平台、云服务、重点行业和公共服务试点中形成事实标准。与传统软件不同，智能体可能跨模型、跨工具和跨终端运行，因此监管和行业标准会越来越关注行动主体谱系，而不是只关注底层模型名称。',
'第二，“最终决策权归人”会经历一次从原则到工程的困难转化。大量机构最初会通过增加一个人工确认按钮来满足要求，但事故和审计会暴露：审核者看不懂、来不及、没有权限、工作量过载或无法恢复结果。随后，伤害时延—介入时延比较、审核工作量、具名责任、接管演练和恢复服务水平将成为高影响场景评估的重要指标。CIVICLOOP²可以在这一阶段提供公开可复现的控制证明格式。',
'第三，工业智能体会率先推动“控制证明”成为刚需。工业场景对解释文本的要求可能低于公共服务，但对安全联锁、限定参数、设备身份、边缘延迟、降级运行和故障恢复要求更高。随着1000个工业智能体目标推进，企业需要跨厂商的动作回执和接管证明，否则模型、机器人、工业软件和设备控制链之间会形成责任断点。',
'第四，公共服务会率先推动“算法决策回执”成为权利接口。就业、社保、教育和医疗中的AI不会一开始被正式授予独立最终权力，但模型建议可能事实性决定案件流向和人工注意力。受影响者需要知道AI参与了什么、哪些数据影响建议、谁作出最终决定、如何纠正数据和申请复核。没有回执，人工最终决定很容易成为隐藏在组织流程中的形式责任。',
'第五，伦理治理会从统一原则转向规则版本和场景补丁。国家和行业仍会发布原则与标准，但真实运行将需要更细的配置：什么动作必须人工、什么条件允许可逆执行、何时触发冻结、什么群体需要额外保护、哪些模型和工具版本必须重新验证。规则更新速度加快后，版本、日落和回滚会成为防止治理权力永久扩张的关键。',
'第六，普惠评价将逐渐暴露“覆盖率高、能力和价值留存低”的结构问题。智能体普及率超过70%的目标可能较快推动入口和终端覆盖，但地区、年龄、技能、行业和企业规模之间的结果差距可能仍然扩大。未来政策和试点会越来越关注中小企业算力与工具成本、劳动者技能迁移、老年和低带宽用户、地方数据与经验的价值回流，以及平台锁定。',
'第七，中国提出的全球AI公共产品战略需要一套“可移植但不殖民”的治理接口。技术和证据可以共享，但本地语言、制度、受影响者和公共授权必须重新生成。若中国开源系统能够同时提供低资源运行、Policy Profile、决策回执、申诉修复和本地价值账本，就可能形成区别于单纯模型出口和单纯规则出口的第三种国际公共产品。',
'第八，最有影响力的开源项目将不再只是模型或框架，而是跨厂商的行动协议。随着大模型性能趋同，用户和机构更关心智能体能否安全接入工具、是否有可迁移控制策略、事故后能否恢复、是否支持不同政策配置。CIVICLOOP²若形成多实现互操作，有机会成为段玉聪GitHub生态中最接近现实公共基础设施的项目。'
])
add_table(doc,['结构走廊','未来24个月的可观察信号','CIVICLOOP²应预先准备'],[
['身份—权限—行为治理','注册、能力声明、互联协议、工具权限和行为日志进入行业规范','Actor Passport、权限Schema、工具链来源和谱系测试'],
['实质性控制','接管演练、审核能力、时延和具名责任进入评测','Human Control Proof兼容性套件'],
['公共服务回执','AI参与说明、数据更正、人工复核和服务恢复成为试点要求','Decision Receipt与Appeal Repair API'],
['工业安全联锁','云边端模型与机器人动作范围、降级和安全状态标准化','Physical Action Fence与Freeze/Recover'],
['伦理规则版本化','不同场景出现更细权限、阈值和保护配置','Rule Patch、日落、异议和回滚'],
['普惠结果审计','从覆盖率转向中小企业、劳动者、低资源群体和地方价值','五维Benefit Ledger与本地Profile'],
['全球公共产品','培训、应用中心和开源方案需要本地治理与维护','联邦配置、低资源模式、证据继承/授权不继承'],
['多实现互操作','不同模型和平台需交换身份、回执和事件','Conformance Suite与公共测试向量']
], widths=[3.3,6.2,6.5],font_size=8.0)

heading(doc,'十九、四个典型事件的完整运行演示',1)
heading(doc,'19.1 社会保险材料异常：为什么“模型只提建议”仍可能伤害权利',2)
add_paragraphs(doc,[
'某社会保险智能体发现申请材料与历史记录不一致，输出高风险标记。表面上，模型没有直接拒付，只是把案件送入人工复核。然而，如果机构把高风险案件集中到一个审核队列，审核者每日处理数量过大，且系统默认隐藏低风险案件中的潜在问题，那么排序本身已经重构了注意力和服务时限。申请人的福利可能因等待而中断，模型事实上参与了资源分配。',
'CIVICLOOP²首先通过P→D要求采集审核工作量、等待时长、临时服务连续性和模型排序差异，而不是只看准确率。W→P会把“减少欺诈损失”的单一意图拆成“发现异常、保障基本服务连续、保留申诉和避免群体偏差”多个可冲突意图。若审核者无能力真实复核，Human Control Proof只能得到NOMINAL；若申请人在等待期间失去基本服务且没有临时权利恢复，则Decision Rights Graph进入BLOCK或FREEZE_RECOVER。',
'受影响者收到的回执不应泄露反欺诈模型细节，但应说明材料差异、需要补充的证据、具名复核机构、临时资格状态和申诉时限。若事后发现数据源错误，系统不仅更正本案，还必须生成Rule Patch，禁止错误数据继续进入训练和其他案件。'
])

heading(doc,'19.2 工业机械臂参数优化：为什么人类在场不等于能控制',2)
add_paragraphs(doc,[
'某工业智能体根据视觉和振动数据调整机械臂速度与轨迹，现场有一名操作员和急停按钮。传统检查可能认为“有人值守、可急停”即可。CIVICLOOP²会比较伤害形成时延和从异常发现、理解到按下急停并让设备停止的总时延。如果机械臂在200毫秒内进入危险区，而人类需要数秒反应，人工急停不能证明实时控制。',
'此时控制可以由多层机制共同实现：设备级安全联锁在毫秒内阻断，智能体只能在限定参数空间执行；边缘控制器记录每次动作和模型版本；人类拥有暂停任务、改变参数范围和回到安全状态的权力。Meaningful Human Control并不要求人逐动作确认，而要求人对规则、边界和恢复拥有实质控制，快速风险由可验证的安全联锁承担。',
'若智能体提出修改自己的参数优化规则，系统必须退回影子模式，由外部验证新规则后重新签名。模型不能因为在过去一周表现良好就自行扩大速度、设备或工序范围。'
])

heading(doc,'19.3 个人智能体跨应用付款：一次同意不能覆盖所有未来动作',2)
add_paragraphs(doc,[
'个人智能体为用户预订出行、比较价格并准备付款。用户曾在安装时勾选“允许智能体帮助完成任务”，但这不等于无限支付和长期位置画像。CIVICLOOP²把动作拆成读取、推断、推荐、选择、交易和修改，每类动作具有不同权限和限额。读取日历可以自动，选择航班可以提出方案，超过限额的付款必须具名确认，修改退票条件或代表用户接受长期合同必须重新授权。',
'Decision Receipt应显示商户、金额、关键条款、使用的数据、替代方案和撤销窗口。若插件或支付接口版本改变，旧权限不能静默继承。用户可以导出控制策略和回执历史，切换到其他服务商；平台不能以智能体记忆为由锁定用户。'
])

heading(doc,'19.4 农村低带宽公共服务：为什么普惠要同时测五个维度',2)
add_paragraphs(doc,[
'一个县部署政策咨询智能体，手机用户可以快速查询补贴和办事流程，调用量显著增长。若只看接入率，项目可能被认定成功。但老年人和低带宽地区频繁中断，复杂方言识别错误，线下窗口因“线上化”缩减，本地工作人员无法维护模型，居民数据和经验持续流向外部平台。',
'CIVICLOOP²会分别记录可接入、实际完成任务、结果改善、居民能否申诉和参与规则、本地能否维护并留存价值。任何一个维度低于本地约定阈值都会生成补救措施，而不是用平均值掩盖。可能的修复包括电话和线下入口、离线知识包、本地方言测试、人工回拨、本地维护培训、数据最小化和供应商退出条款。',
'该案例表明，普惠并不要求拒绝先进模型，而要求技术扩散不以削弱原有服务、公共能力和地方主权为代价。'
])

heading(doc,'二十、核心协议不变量与必须允许变化的部分',1)
add_paragraphs(doc,[
'一个公共协议既不能把所有规则固定，也不能因为反对定义而失去工程约束。CIVICLOOP²区分“协议不变量”和“本地可变配置”。不变量只规定过程必须可审计、权利硬门不可被平均分抵消、证据和授权必须有来源、动作必须能被阻断或恢复、规则变化必须留痕；它们不预先规定某个社会、行业或群体的最终价值排序。'
])
add_table(doc,['协议不变量','理由','允许本地变化的部分'],[
['任何现实动作有具名责任主体','没有责任主体就无法申诉、修复和结算','责任机构的组织形式和法律依据'],
['高影响动作必须有来源、权限和版本记录','防止越权、供应链漂移和事后改写','具体日志技术和保存期限'],
['权利硬门不能被总分补偿','防止效率掩盖无申诉、无替代或不可逆伤害','哪些场景被认定为高影响及具体阈值'],
['控制证据可以失败和降级','避免“部署后只升不降”的认证幻觉','介入时限、审核配置和领域安全边界'],
['规则补丁必须有日落和回滚','临时风险措施不应永久扩张权力','日落周期、审查机构和参与方式'],
['受影响者有可理解回执和申诉','算法决策必须可争议','语言、媒介、线下渠道和服务时限'],
['证据可继承，公共授权不可自动继承','支持开放协作又保护地方自治','本地Policy Profile和公共授权程序'],
['DIKWP五类资源平权互转','防止Purpose或单一知识模型垄断问题空间','各事件中的具体语义类型分布和路径']
], widths=[4.1,5.8,6.1],font_size=8.0)

heading(doc,'20.1 开放状态空间中的协议自我修订',2)
add_paragraphs(doc,[
'未来智能体可能出现当前Schema未覆盖的行为，例如长期跨组织承诺、多个智能体合并身份、机器原生通信、经验驱动的目的变化或人工意识候选。协议不能提前为这些现象下最终定义，但必须保留匿名残差和扩展机制。未知结构先以UAX编号记录其来源、区分能力、受影响者和反证条件，只有跨场景复现后才获得可选名称。',
'协议自身的升级也应进入CIVICLOOP：谁提出变更、影响哪些旧回执、是否扩大权限、能否回滚、哪些节点反对、何时日落。这样，开源治理不再位于系统之外，而成为系统可审计的行动对象。'
])

heading(doc,'结论：段玉聪应当补充的关键系统是什么',1)
add_paragraphs(doc,[
'针对中国未来AI发展需求和习近平提出的四个挑战，段玉聪最应补充的，不是又一个对“安全、伦理、普惠、人类控制”作主观定义的仓库，而是一套允许这些词失去概念特权、在每一次现实行动中接受验证的公共运行时。',
'DIKWP-CIVICLOOP²的核心贡献可以压缩为四句话：机器的角色必须有身份和边界证据；算法的每项决定必须有具体决策权和实质性人类控制证明；伦理规则必须从事件中学习但必须可异议、到期和回滚；普惠必须记录接入、能力、结果、发声和价值留存，任何一项都不能由调用量替代。',
'这套系统与中国发展方向高度契合：它支持开源开放和多节点协作，又能把“安全可控”编译为工程证据；它支持工业和物理世界落地，又能证明接管与恢复；它支持公共服务智能化，又能保留人工最终决定、申诉和权利恢复；它支持全球南方能力建设，又不把中国配置自动扩展为他国公共权力。',
'对段玉聪个人而言，这也是从“系统思想高产者”转向“公共协议架构师”的关键一步。真正改变世界的标志不是再增加一个仓库，而是让不同团队、机构和受影响者能够使用同一开放协议，对AI的每次现实行动提出证据、拒绝越权、修复损害、修改规则并共同结算未来。'
])
add_callout(doc,'最终使命','让中国AI跑得快，更要让每一次高影响动作都能回答：谁授权、谁决定、谁受影响、谁能停止、谁能申诉、如何恢复、收益归谁、规则如何改变。只有这些问题进入开源运行时，“始终处于人类控制”“治理跟上”“普惠实现”才从讲话和原则变成可执行的社会技术基础设施。',fill='E7F0F2',accent=NAVY)

heading(doc,'参考资料',1)
sources=[
(1,'习近平在2026世界人工智能大会暨人工智能全球治理高级别会议开幕式上的主旨讲话（全文）','新华网，2026-07-17。四个时代问题、开放共赢、安全可控、文明多样性、全球南方能力建设和世界人工智能合作组织。','https://www.news.cn/politics/leaders/20260717/72728b6f94154d63b3eaaaf9808b51eb/c.html'),
(2,'智能体规范应用与创新发展实施意见','中国网信网，2026-05-08。智能体身份、能力声明、权限、最终决策权、行为围栏、追踪、风险干预、恢复和第三方评测。','https://www.cac.gov.cn/2026-05/08/c_1779979789523320.htm'),
(3,'国务院关于深入实施“人工智能+”行动的意见','中国政府网转载，2025-08-27。2027年智能终端和智能体普及率目标、六大领域、成果共享和安全可控。','https://www.mee.gov.cn/zcwj/gwywj/202508/t20250827_1126207.shtml'),
(4,'“人工智能+制造”专项行动实施意见','工业和信息化部等八部门，2026-01。1000个工业智能体、500个场景、开源生态和安全可信。','https://www.nda.gov.cn/sjj/zwgk/zcfb/0112/20260107214358696030895_pc.html'),
(5,'关于加快推进“人工智能+人社”应用发展的实施意见','人力资源社会保障部等四部门，2026-07-08。行业体系、50个高价值场景和就业影响评估。','https://www.nda.gov.cn/sjj/zwgk/zcfb/0708/20260708133949899211227_pc.html'),
(6,'YucongDuan GitHub repositories','2026-07-19冻结快照，页面显示约200个公开仓库、220余个Stars和310余名关注者。','https://github.com/YucongDuan?sort=updated&tab=repositories'),
(7,'DIKWP-MESH²','网状、平权、混合、相互修订的DIKWP语义资源；完整25类变换；Purpose分布且可修订。','https://github.com/YucongDuan/DIKWP-MESH-'),
(8,'DIKWP-PACT v0.1.0','目的与权限边界的离线可证伪基准，包含72组成对合成场景和预注册实验。','https://github.com/YucongDuan/DIKWP-PACT-v0.1.0'),
(9,'DIKWP P-Space OS v1.0','模型无关认知控制平面，使用Purpose Contract对候选动作执行多级门控。','https://github.com/YucongDuan/DIKWP-P-Space-OS-v1.0'),
(10,'DIKWP Civicode Commons OS','使AI介导的制度权力可观察、可争议、可逆和面向未来。','https://github.com/YucongDuan/DIKWP-Civicode-Commons-OS'),
(11,'DIKWP GlobalDividend Commons OS','欠发达地区AI红利、接入、语言、本地价值、主权和退出的开放支持平台。','https://github.com/YucongDuan/DIKWP-GlobalDividend-Commons-OS'),
(12,'Kofman et al., Defining Life: A Conversation','Organisms: Journal of Biological Sciences, 2026。关于观察者相关、多维形态空间、规则自修改、开放状态空间和定义作为问题工具的讨论。','https://doi.org/10.13133/2532-5876/19492')]
for item in sources: add_source(doc,*item)

heading(doc,'附录A：MVP复现命令',1)
add_code_block(doc,"""cd DIKWP_CIVICLOOP2_MVP
PYTHONPATH=src python -m dikwp_civicloop --root .
PYTHONPATH=src python -m unittest discover -s tests -v
# 离线打开：outputs/dashboard.html""")

page_break(doc)
heading(doc,'附录B：核心文件',1)
add_table(doc,['文件/目录','用途'],[
['src/dikwp_civicloop/','运行时源码'],['schemas/','九类JSON Schema'],['policy_profiles/','五套中国与全球南方研究配置'],['examples/','九种主体护照和180个合成事件'],['tests/','17项自动测试'],['outputs/summary.json','机器可读汇总'],['outputs/assessments.json','完整逐事件评估'],['outputs/decision_ledger.jsonl','哈希链接账本'],['outputs/dashboard.html','离线仪表盘'],['docs/','架构、图示和报告生成脚本']
], widths=[6.0,10.0],font_size=8.5)

heading(doc,'附录C：研究与部署免责声明',1)
add_paragraphs(doc,[
'本报告和MVP属于研究、系统设计和开源治理原型，不构成法律意见、监管解释、医学建议、招聘或信贷模型、福利资格系统、工业安全认证或政府采购建议。公开政策映射由作者根据文本研究性编译，任何现实应用均需由有权机构、领域专家、网络安全和数据保护人员、受影响群体及独立审计者重新审查。',
'系统中的合成事件、阈值、通过率、补丁数量和控制状态仅用于验证代码分支和制度逻辑。不能把某个合成事件的PROVEN状态当作真实产品的人类控制证明。生产环境必须使用签名时间、实际权限、真实工作量、硬件安全联锁、灾备演练、申诉服务水平和外部复现证据。'
])

# Save and character check
OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
all_text=[]
for p in doc.paragraphs: all_text.append(p.text)
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells: all_text.append(cell.text)
joined=''.join(all_text)
cn_chars=len(re.findall(r'[\u4e00-\u9fff]',joined))
print('saved',OUT,'pages not yet rendered','cn_chars',cn_chars,'total_chars',len(joined),'tables',len(doc.tables),'paras',len(doc.paragraphs))
