# Code of Conduct

Participants must engage respectfully, disclose conflicts of interest, protect sensitive data, and distinguish evidence from advocacy. Affected people are not merely test subjects: their objections, lived consequences and right to exit are valid inputs to the protocol.
