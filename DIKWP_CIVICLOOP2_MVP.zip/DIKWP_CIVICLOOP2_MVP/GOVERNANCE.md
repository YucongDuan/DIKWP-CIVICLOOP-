# Governance

CIVICLOOP² uses a federated governance model:

- **Runtime maintainers** protect code quality and backward compatibility.
- **Policy profile maintainers** are domain- and jurisdiction-specific and cannot modify the core runtime unilaterally.
- **Affected-party reviewers** may veto a deployment profile when appeal, access or repair is inadequate.
- **Security maintainers** may freeze a release or profile.
- **Independent settlement reviewers** evaluate pilots and cannot be the original operator.

A profile is evidence and policy configuration, not a universal definition. Every profile must declare provenance, expiry, affected groups and a rollback condition. Forks are legitimate and must preserve lineage.
